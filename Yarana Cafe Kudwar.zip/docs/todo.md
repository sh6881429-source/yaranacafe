# Todo
- #2: Add minimum order setting in admin panel and payment QR URL configuration
- #3: Implement QR code table ordering page with order type detection
- #4: Add payment options (₹50 advance vs full) with UTR entry in checkout
- #5: Add payment verification controls in admin panel
- #6: Update rider panel to show payment status and total amount
- #7: Add mobile optimizations for QR scanning and payment flow
