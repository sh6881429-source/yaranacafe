export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  image: string;
  isVeg: boolean;
  isAvailable: boolean;
}

export const menuItems: MenuItem[] = [
  {
    id: '1',
    name: 'Paneer Tikka Masala',
    description: 'Cottage cheese cubes in rich tomato and cream gravy',
    price: 280,
    category: 'Main Course',
    image: 'https://images.unsplash.com/photo-1631452180519-c014fe946bc7?w=400',
    isVeg: true,
    isAvailable: true,
  },
  {
    id: '2',
    name: 'Butter Chicken',
    description: 'Tender chicken in creamy tomato butter sauce',
    price: 320,
    category: 'Main Course',
    image: 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?w=400',
    isVeg: false,
    isAvailable: true,
  },
  {
    id: '3',
    name: 'Dal Makhani',
    description: 'Black lentils slow-cooked with butter and cream',
    price: 220,
    category: 'Main Course',
    image: 'https://images.unsplash.com/photo-1546833998-877b37c2e5c6?w=400',
    isVeg: true,
    isAvailable: true,
  },
  {
    id: '4',
    name: 'Chicken Biryani',
    description: 'Fragrant basmati rice with tender chicken pieces',
    price: 350,
    category: 'Rice',
    image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=400',
    isVeg: false,
    isAvailable: true,
  },
  {
    id: '5',
    name: 'Veg Biryani',
    description: 'Aromatic rice with mixed vegetables and spices',
    price: 280,
    category: 'Rice',
    image: 'https://images.unsplash.com/photo-1642821373181-696a54913e93?w=400',
    isVeg: true,
    isAvailable: true,
  },
  {
    id: '6',
    name: 'Garlic Naan',
    description: 'Freshly baked bread with garlic and butter',
    price: 60,
    category: 'Bread',
    image: 'https://images.unsplash.com/photo-1619888355804-42a785e93d40?w=400',
    isVeg: true,
    isAvailable: true,
  },
  {
    id: '7',
    name: 'Tandoori Roti',
    description: 'Whole wheat bread from clay oven',
    price: 40,
    category: 'Bread',
    image: 'https://images.unsplash.com/photo-1628840042765-356cda07504e?w=400',
    isVeg: true,
    isAvailable: true,
  },
  {
    id: '8',
    name: 'Samosa',
    description: 'Crispy pastry filled with spiced potatoes and peas',
    price: 50,
    category: 'Starters',
    image: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=400',
    isVeg: true,
    isAvailable: true,
  },
  {
    id: '9',
    name: 'Chicken 65',
    description: 'Spicy deep-fried chicken appetizer',
    price: 240,
    category: 'Starters',
    image: 'https://images.unsplash.com/photo-1610057099443-fde8c4d50f91?w=400',
    isVeg: false,
    isAvailable: true,
  },
  {
    id: '10',
    name: 'Gulab Jamun',
    description: 'Soft milk dumplings in sugar syrup',
    price: 80,
    category: 'Desserts',
    image: 'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?w=400',
    isVeg: true,
    isAvailable: true,
  },
  {
    id: '11',
    name: 'Mango Lassi',
    description: 'Sweet yogurt drink with mango pulp',
    price: 90,
    category: 'Beverages',
    image: 'https://images.unsplash.com/photo-1623065422902-30a2d299bbe4?w=400',
    isVeg: true,
    isAvailable: true,
  },
  {
    id: '12',
    name: 'Masala Chai',
    description: 'Traditional Indian spiced tea',
    price: 40,
    category: 'Beverages',
    image: 'https://images.unsplash.com/photo-1597481499750-3e6b22637e12?w=400',
    isVeg: true,
    isAvailable: true,
  },
];

export const categories = [
  'All',
  'Starters',
  'Main Course',
  'Rice',
  'Bread',
  'Desserts',
  'Beverages',
];
