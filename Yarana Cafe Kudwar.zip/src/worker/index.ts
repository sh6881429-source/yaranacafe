import { Hono } from "hono";
import {
  exchangeCodeForSessionToken,
  getOAuthRedirectUrl,
  authMiddleware,
  deleteSession,
  MOCHA_SESSION_TOKEN_COOKIE_NAME,
} from "@getmocha/users-service/backend";
import { getCookie, setCookie } from "hono/cookie";

const app = new Hono<{ Bindings: Env }>();

// OAuth redirect URL endpoint
app.get("/api/oauth/google/redirect_url", async (c) => {
  const redirectUrl = await getOAuthRedirectUrl("google", {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  return c.json({ redirectUrl }, 200);
});

// Exchange code for session token
app.post("/api/sessions", async (c) => {
  const body = await c.req.json();

  if (!body.code) {
    return c.json({ error: "No authorization code provided" }, 400);
  }

  const sessionToken = await exchangeCodeForSessionToken(body.code, {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, sessionToken, {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 60 * 24 * 60 * 60, // 60 days
  });

  return c.json({ success: true }, 200);
});

// Get current user with role information
app.get("/api/users/me", authMiddleware, async (c) => {
  const mochaUser = c.get("user");
  
  if (!mochaUser) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  // Check if user exists in our database
  const dbUser = await c.env.DB.prepare(
    "SELECT id, email, name, phone, address, role, is_active FROM users WHERE id = ?"
  )
    .bind(mochaUser.id)
    .first();

  if (!dbUser) {
    // Create new user with customer role by default
    // Check if this email should be admin
    const isAdmin = mochaUser.email === 'admin@yaranacafe.com';
    const role = isAdmin ? 'admin' : 'customer';
    
    await c.env.DB.prepare(
      "INSERT INTO users (id, email, name, role, is_active) VALUES (?, ?, ?, ?, 1)"
    )
      .bind(mochaUser.id, mochaUser.email, mochaUser.google_user_data.name || mochaUser.email, role)
      .run();

    return c.json({
      ...mochaUser,
      role,
      name: mochaUser.google_user_data.name || mochaUser.email,
      phone: null,
      address: null,
      is_active: true,
    });
  }

  return c.json({
    ...mochaUser,
    role: dbUser.role,
    name: dbUser.name,
    phone: dbUser.phone,
    address: dbUser.address,
    is_active: dbUser.is_active === 1,
  });
});

// Update user profile
app.patch("/api/users/me", authMiddleware, async (c) => {
  const mochaUser = c.get("user");
  
  if (!mochaUser) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  const body = await c.req.json();

  const { name, phone, address } = body;

  await c.env.DB.prepare(
    "UPDATE users SET name = ?, phone = ?, address = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
  )
    .bind(name, phone, address, mochaUser.id)
    .run();

  return c.json({ success: true });
});

// Get all users (admin only - OAuth)
app.get("/api/users", authMiddleware, async (c) => {
  const currentUser = c.get("user");
  
  if (!currentUser) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  const adminCheck = await c.env.DB.prepare(
    "SELECT role FROM users WHERE id = ?"
  )
    .bind(currentUser.id)
    .first();

  if (!adminCheck || adminCheck.role !== 'admin') {
    return c.json({ error: "Unauthorized" }, 403);
  }

  const { results } = await c.env.DB.prepare(
    "SELECT id, email, name, phone, address, role, is_active, created_at, password FROM users ORDER BY created_at DESC"
  ).all();

  return c.json(results);
});

// Get all users (admin only - password auth)
app.get("/api/admin/users", async (c) => {
  const adminPassword = c.req.header('X-Admin-Password');
  
  if (adminPassword !== 'Yaranacafe8948') {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const { results } = await c.env.DB.prepare(
    "SELECT id, email, name, phone, address, role, is_active, created_at, password FROM users ORDER BY created_at DESC"
  ).all();

  return c.json(results);
});

// Create new user/rider (admin only)
app.post("/api/users", async (c) => {
  const body = await c.req.json();
  
  // Check for admin password
  if (body.admin_password !== 'Yaranacafe8948') {
    return c.json({ error: "Unauthorized" }, 401);
  }
  const { name, user_id, phone, password } = body;
  const userRole = body.role || 'rider';

  if (!name || !user_id || !phone) {
    return c.json({ error: "Name, user ID, and phone are required" }, 400);
  }

  if (!password) {
    return c.json({ error: "Password is required" }, 400);
  }

  if (!['customer', 'rider', 'admin'].includes(userRole)) {
    return c.json({ error: "Invalid role" }, 400);
  }

  // Check if user_id already exists
  const existingUser = await c.env.DB.prepare(
    "SELECT id FROM users WHERE id = ?"
  )
    .bind(user_id)
    .first();

  if (existingUser) {
    return c.json({ error: "User ID already exists" }, 400);
  }

  // Generate unique email for rider using their user_id
  const riderEmail = `${user_id}@yaranacafe.internal`;
  
  await c.env.DB.prepare(
    "INSERT INTO users (id, email, name, phone, role, password, is_active) VALUES (?, ?, ?, ?, ?, ?, 1)"
  )
    .bind(user_id, riderEmail, name, phone, userRole, password)
    .run();

  return c.json({ success: true, userId: user_id });
});

// Update user details (admin only)
app.patch("/api/users/:userId", async (c) => {
  const userId = c.req.param("userId");
  const body = await c.req.json();
  
  // Check for admin password
  if (body.admin_password !== 'Yaranacafe8948') {
    return c.json({ error: "Unauthorized" }, 401);
  }
  const { name, phone, role, password } = body;

  if (role && !['customer', 'rider', 'admin'].includes(role)) {
    return c.json({ error: "Invalid role" }, 400);
  }

  if (password !== undefined) {
    await c.env.DB.prepare(
      "UPDATE users SET name = ?, phone = ?, role = ?, password = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
    )
      .bind(name, phone, role, password, userId)
      .run();
  } else {
    await c.env.DB.prepare(
      "UPDATE users SET name = ?, phone = ?, role = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
    )
      .bind(name, phone, role, userId)
      .run();
  }

  return c.json({ success: true });
});

// Delete user (admin only)
app.delete("/api/users/:userId", async (c) => {
  const userId = c.req.param("userId");
  const adminPassword = c.req.header('X-Admin-Password');
  
  if (adminPassword !== 'Yaranacafe8948') {
    return c.json({ error: "Unauthorized" }, 401);
  }

  // Don't allow deleting if user has orders assigned
  const ordersCheck = await c.env.DB.prepare(
    "SELECT COUNT(*) as count FROM orders WHERE rider_id = ?"
  )
    .bind(userId)
    .first();

  if (ordersCheck && (ordersCheck.count as number) > 0) {
    return c.json({ error: "Cannot delete user with assigned orders" }, 400);
  }

  await c.env.DB.prepare(
    "DELETE FROM users WHERE id = ?"
  )
    .bind(userId)
    .run();

  return c.json({ success: true });
});

// Get all menu items (public)
app.get("/api/menu", async (c) => {
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM menu_items ORDER BY category, name"
  ).all();

  return c.json(results);
});

// Create menu item (admin only)
app.post("/api/menu", async (c) => {
  const body = await c.req.json();
  
  // Check for admin password
  if (body.admin_password !== 'Yaranacafe8948') {
    return c.json({ error: "Unauthorized" }, 401);
  }
  const { name, description, price, category, image, is_veg, is_available } = body;

  if (!name || !price || !category) {
    return c.json({ error: "Name, price, and category are required" }, 400);
  }

  await c.env.DB.prepare(
    "INSERT INTO menu_items (name, description, price, category, image, is_veg, is_available) VALUES (?, ?, ?, ?, ?, ?, ?)"
  )
    .bind(name, description || null, price, category, image || null, is_veg ? 1 : 0, is_available ? 1 : 0)
    .run();

  return c.json({ success: true });
});

// Update menu item (admin only)
app.patch("/api/menu/:itemId", async (c) => {
  const itemId = c.req.param("itemId");
  const body = await c.req.json();
  
  // Check for admin password
  if (body.admin_password !== 'Yaranacafe8948') {
    return c.json({ error: "Unauthorized" }, 401);
  }
  const { name, description, price, category, image, is_veg, is_available } = body;

  await c.env.DB.prepare(
    "UPDATE menu_items SET name = ?, description = ?, price = ?, category = ?, image = ?, is_veg = ?, is_available = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
  )
    .bind(name, description, price, category, image, is_veg ? 1 : 0, is_available ? 1 : 0, itemId)
    .run();

  return c.json({ success: true });
});

// Delete menu item (admin only)
app.delete("/api/menu/:itemId", async (c) => {
  const itemId = c.req.param("itemId");
  const adminPassword = c.req.header('X-Admin-Password');
  
  // Check for admin password in header
  if (adminPassword !== 'Yaranacafe8948') {
    return c.json({ error: "Unauthorized" }, 401);
  }

  await c.env.DB.prepare(
    "DELETE FROM menu_items WHERE id = ?"
  )
    .bind(itemId)
    .run();

  return c.json({ success: true });
});

// Get settings (public)
app.get("/api/settings", async (c) => {
  const { results } = await c.env.DB.prepare(
    "SELECT key, value FROM settings"
  ).all();

  const settings: Record<string, string> = {};
  results.forEach((row: any) => {
    settings[row.key] = row.value;
  });

  return c.json(settings);
});

// Update settings (admin only)
app.patch("/api/settings", async (c) => {
  const body = await c.req.json();
  
  // Check for admin password
  if (body.admin_password !== 'Yaranacafe8948') {
    return c.json({ error: "Unauthorized" }, 401);
  }
  const { phone_1, phone_2, email, minimum_order_amount, payment_qr_url } = body;

  if (phone_1 !== undefined) {
    await c.env.DB.prepare(
      "UPDATE settings SET value = ?, updated_at = CURRENT_TIMESTAMP WHERE key = 'phone_1'"
    )
      .bind(phone_1)
      .run();
  }

  if (phone_2 !== undefined) {
    await c.env.DB.prepare(
      "UPDATE settings SET value = ?, updated_at = CURRENT_TIMESTAMP WHERE key = 'phone_2'"
    )
      .bind(phone_2)
      .run();
  }

  if (email !== undefined) {
    await c.env.DB.prepare(
      "UPDATE settings SET value = ?, updated_at = CURRENT_TIMESTAMP WHERE key = 'email'"
    )
      .bind(email)
      .run();
  }

  if (minimum_order_amount !== undefined) {
    await c.env.DB.prepare(
      "UPDATE settings SET value = ?, updated_at = CURRENT_TIMESTAMP WHERE key = 'minimum_order_amount'"
    )
      .bind(String(minimum_order_amount))
      .run();
  }

  if (payment_qr_url !== undefined) {
    await c.env.DB.prepare(
      "UPDATE settings SET value = ?, updated_at = CURRENT_TIMESTAMP WHERE key = 'payment_qr_url'"
    )
      .bind(payment_qr_url)
      .run();
  }

  return c.json({ success: true });
});

// Create guest order (no authentication required)
app.post("/api/orders/guest", async (c) => {
  const body = await c.req.json();

  const { items, name, address, phone, notes, order_type, table_number, payment_option, paid_amount, utr_number } = body;

  if (!items || items.length === 0) {
    return c.json({ error: "No items in order" }, 400);
  }

  const totalAmount = items.reduce((sum: number, item: any) => sum + item.price * item.quantity, 0);

  // Check minimum order for delivery orders only
  if (order_type === 'delivery' || !order_type) {
    const settingsResult = await c.env.DB.prepare(
      "SELECT value FROM settings WHERE key = 'minimum_order_amount'"
    ).first();
    
    const minOrder = settingsResult ? parseInt(settingsResult.value as string) : 0;
    if (minOrder > 0 && totalAmount < minOrder) {
      return c.json({ 
        error: `Minimum order amount is ₹${minOrder} for delivery orders`,
        minimum_order: minOrder 
      }, 400);
    }

    if (!name || !phone || !address) {
      return c.json({ error: "Name, phone, and delivery address are required" }, 400);
    }
  } else {
    // Table orders
    if (!name || !phone) {
      return c.json({ error: "Name and phone are required" }, 400);
    }
  }

  // Validate payment for delivery orders
  if (order_type === 'delivery' || !order_type) {
    if (!payment_option || !paid_amount || !utr_number) {
      return c.json({ error: "Payment details are required for delivery orders" }, 400);
    }

    if (utr_number.length !== 12 || !/^\d+$/.test(utr_number)) {
      return c.json({ error: "UTR number must be exactly 12 digits" }, 400);
    }
  }

  const orderNumber = `ORD-${Date.now()}`;
  const finalAddress = order_type === 'table' ? `Table ${table_number}` : address;
  const finalOrderType = order_type || 'delivery';

  const orderResult = await c.env.DB.prepare(
    "INSERT INTO orders (order_number, customer_id, customer_name, customer_phone, customer_address, total_amount, status, notes, order_type, table_number, payment_option, paid_amount, utr_number, is_payment_verified) VALUES (?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?, ?, ?, ?, 0)"
  )
    .bind(
      orderNumber, 
      'guest', 
      name, 
      phone, 
      finalAddress, 
      totalAmount, 
      notes || null,
      finalOrderType,
      table_number || null,
      payment_option || null,
      paid_amount || null,
      utr_number || null
    )
    .run();

  const orderId = orderResult.meta.last_row_id;

  for (const item of items) {
    await c.env.DB.prepare(
      "INSERT INTO order_items (order_id, item_name, item_price, quantity) VALUES (?, ?, ?, ?)"
    )
      .bind(orderId, item.name, item.price, item.quantity)
      .run();
  }

  return c.json({ success: true, orderId, orderNumber });
});

// Create order (authenticated)
app.post("/api/orders", authMiddleware, async (c) => {
  const currentUser = c.get("user");
  
  if (!currentUser) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  const body = await c.req.json();

  const { items, address, phone, notes, order_type, table_number, payment_option, paid_amount, utr_number } = body;

  if (!items || items.length === 0) {
    return c.json({ error: "No items in order" }, 400);
  }

  const totalAmount = items.reduce((sum: number, item: any) => sum + item.price * item.quantity, 0);

  // Check minimum order for delivery orders only
  if (order_type === 'delivery' || !order_type) {
    const settingsResult = await c.env.DB.prepare(
      "SELECT value FROM settings WHERE key = 'minimum_order_amount'"
    ).first();
    
    const minOrder = settingsResult ? parseInt(settingsResult.value as string) : 0;
    if (minOrder > 0 && totalAmount < minOrder) {
      return c.json({ 
        error: `Minimum order amount is ₹${minOrder} for delivery orders`,
        minimum_order: minOrder 
      }, 400);
    }

    if (!address) {
      return c.json({ error: "Delivery address is required" }, 400);
    }

    // Validate payment for delivery orders
    if (!payment_option || !paid_amount || !utr_number) {
      return c.json({ error: "Payment details are required for delivery orders" }, 400);
    }

    if (utr_number.length !== 12 || !/^\d+$/.test(utr_number)) {
      return c.json({ error: "UTR number must be exactly 12 digits" }, 400);
    }
  }

  const orderNumber = `ORD-${Date.now()}`;
  const finalAddress = order_type === 'table' ? `Table ${table_number}` : address;
  const finalOrderType = order_type || 'delivery';

  const user = await c.env.DB.prepare(
    "SELECT name, phone FROM users WHERE id = ?"
  )
    .bind(currentUser.id)
    .first();

  const orderResult = await c.env.DB.prepare(
    "INSERT INTO orders (order_number, customer_id, customer_name, customer_phone, customer_address, total_amount, status, notes, order_type, table_number, payment_option, paid_amount, utr_number, is_payment_verified) VALUES (?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?, ?, ?, ?, ?)"
  )
    .bind(
      orderNumber, 
      currentUser.id, 
      user?.name || currentUser.email, 
      phone || user?.phone, 
      finalAddress, 
      totalAmount, 
      notes || null,
      finalOrderType,
      table_number || null,
      payment_option || null,
      paid_amount || null,
      utr_number || null,
      order_type === 'table' ? 1 : 0
    )
    .run();

  const orderId = orderResult.meta.last_row_id;

  for (const item of items) {
    await c.env.DB.prepare(
      "INSERT INTO order_items (order_id, item_name, item_price, quantity) VALUES (?, ?, ?, ?)"
    )
      .bind(orderId, item.name, item.price, item.quantity)
      .run();
  }

  return c.json({ success: true, orderId, orderNumber });
});

// Get all orders (admin and riders see all, customers see their own)
app.get("/api/orders", authMiddleware, async (c) => {
  const currentUser = c.get("user");
  
  if (!currentUser) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  const user = await c.env.DB.prepare(
    "SELECT role FROM users WHERE id = ?"
  )
    .bind(currentUser.id)
    .first();

  let query;
  if (user?.role === 'admin' || user?.role === 'rider') {
    query = c.env.DB.prepare(
      "SELECT * FROM orders ORDER BY created_at DESC"
    );
  } else {
    query = c.env.DB.prepare(
      "SELECT * FROM orders WHERE customer_id = ? ORDER BY created_at DESC"
    ).bind(currentUser.id);
  }

  const { results } = await query.all();

  const ordersWithItems = await Promise.all(
    results.map(async (order: any) => {
      const { results: items } = await c.env.DB.prepare(
        "SELECT * FROM order_items WHERE order_id = ?"
      )
        .bind(order.id)
        .all();

      // Get rider info if assigned
      let riderInfo = null;
      if (order.rider_id) {
        riderInfo = await c.env.DB.prepare(
          "SELECT name, phone FROM users WHERE id = ?"
        )
          .bind(order.rider_id)
          .first();
      }

      return { ...order, items, rider: riderInfo };
    })
  );

  return c.json(ordersWithItems);
});

// Get all orders (admin - password auth)
app.get("/api/admin/orders", async (c) => {
  const adminPassword = c.req.header('X-Admin-Password');
  
  if (adminPassword !== 'Yaranacafe8948') {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const { results } = await c.env.DB.prepare(
    "SELECT * FROM orders ORDER BY created_at DESC"
  ).all();

  const ordersWithItems = await Promise.all(
    results.map(async (order: any) => {
      const { results: items } = await c.env.DB.prepare(
        "SELECT * FROM order_items WHERE order_id = ?"
      )
        .bind(order.id)
        .all();

      let riderInfo = null;
      if (order.rider_id) {
        riderInfo = await c.env.DB.prepare(
          "SELECT name, phone FROM users WHERE id = ?"
        )
          .bind(order.rider_id)
          .first();
      }

      return { ...order, items, rider: riderInfo };
    })
  );

  return c.json(ordersWithItems);
});

// Get orders for rider (password auth)
app.get("/api/rider/orders/:riderId", async (c) => {
  const riderId = c.req.param("riderId");
  const riderPassword = c.req.header('X-Rider-Password');
  
  // Verify rider credentials
  const rider = await c.env.DB.prepare(
    "SELECT password, role FROM users WHERE id = ? AND role = 'rider'"
  )
    .bind(riderId)
    .first();

  if (!rider || rider.password !== riderPassword) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const { results } = await c.env.DB.prepare(
    "SELECT * FROM orders WHERE rider_id = ? OR (rider_id IS NULL AND status = 'ready') ORDER BY created_at DESC"
  )
    .bind(riderId)
    .all();

  const ordersWithItems = await Promise.all(
    results.map(async (order: any) => {
      const { results: items } = await c.env.DB.prepare(
        "SELECT * FROM order_items WHERE order_id = ?"
      )
        .bind(order.id)
        .all();

      return { ...order, items };
    })
  );

  return c.json(ordersWithItems);
});

// Verify payment (admin only)
app.patch("/api/admin/orders/:orderId/verify-payment", async (c) => {
  const adminPassword = c.req.header('X-Admin-Password');
  
  if (adminPassword !== 'Yaranacafe8948') {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const orderId = c.req.param("orderId");

  await c.env.DB.prepare(
    "UPDATE orders SET is_payment_verified = 1, status = 'confirmed', updated_at = CURRENT_TIMESTAMP WHERE id = ?"
  )
    .bind(orderId)
    .run();

  return c.json({ success: true });
});

// Update order status (admin - password auth)
app.patch("/api/admin/orders/:orderId", async (c) => {
  const adminPassword = c.req.header('X-Admin-Password');
  
  if (adminPassword !== 'Yaranacafe8948') {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const orderId = c.req.param("orderId");
  const body = await c.req.json();
  const { status, rider_id } = body;

  const validStatuses = ['pending', 'confirmed', 'preparing', 'ready', 'picked_up', 'delivered', 'cancelled'];
  if (status && !validStatuses.includes(status)) {
    return c.json({ error: "Invalid status" }, 400);
  }

  await c.env.DB.prepare(
    "UPDATE orders SET status = ?, rider_id = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
  )
    .bind(status, rider_id || null, orderId)
    .run();

  return c.json({ success: true });
});

// Update order status (rider - password auth)
app.patch("/api/rider/orders/:orderId", async (c) => {
  const orderId = c.req.param("orderId");
  const body = await c.req.json();
  const { riderId, riderPassword, status, rider_id } = body;
  
  // Verify rider credentials
  const rider = await c.env.DB.prepare(
    "SELECT password, role FROM users WHERE id = ? AND role = 'rider'"
  )
    .bind(riderId)
    .first();

  if (!rider || rider.password !== riderPassword) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const validStatuses = ['pending', 'confirmed', 'preparing', 'ready', 'picked_up', 'delivered', 'cancelled'];
  if (status && !validStatuses.includes(status)) {
    return c.json({ error: "Invalid status" }, 400);
  }

  await c.env.DB.prepare(
    "UPDATE orders SET status = ?, rider_id = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
  )
    .bind(status, rider_id || null, orderId)
    .run();

  return c.json({ success: true });
});

// Update order status (admin and riders - OAuth)
app.patch("/api/orders/:orderId", authMiddleware, async (c) => {
  const currentUser = c.get("user");
  
  if (!currentUser) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  const user = await c.env.DB.prepare(
    "SELECT role FROM users WHERE id = ?"
  )
    .bind(currentUser.id)
    .first();

  if (user?.role !== 'admin' && user?.role !== 'rider') {
    return c.json({ error: "Unauthorized" }, 403);
  }

  const orderId = c.req.param("orderId");
  const body = await c.req.json();
  const { status, rider_id } = body;

  const validStatuses = ['pending', 'confirmed', 'preparing', 'ready', 'picked_up', 'delivered', 'cancelled'];
  if (status && !validStatuses.includes(status)) {
    return c.json({ error: "Invalid status" }, 400);
  }

  await c.env.DB.prepare(
    "UPDATE orders SET status = ?, rider_id = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
  )
    .bind(status, rider_id || null, orderId)
    .run();

  return c.json({ success: true });
});

// Logout
app.get("/api/logout", async (c) => {
  const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);

  if (typeof sessionToken === "string") {
    await deleteSession(sessionToken, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });
  }

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, "", {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 0,
  });

  return c.json({ success: true }, 200);
});

export default app;
