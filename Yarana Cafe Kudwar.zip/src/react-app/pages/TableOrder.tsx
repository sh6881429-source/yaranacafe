import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router';
import { ShoppingCart, Plus, Minus } from 'lucide-react';
import CheckoutModal from '../components/CheckoutModal';

interface MenuItem {
  id: number;
  name: string;
  description: string;
  price: number;
  category: string;
  image: string;
  is_veg: number;
  is_available: number;
}

interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
}

export default function TableOrder() {
  const [searchParams] = useSearchParams();
  const tableNumber = searchParams.get('table') || '1';
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [showCheckout, setShowCheckout] = useState(false);
  const [orderSuccess, setOrderSuccess] = useState(false);
  const [orderNumber, setOrderNumber] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchMenu();
  }, []);

  const fetchMenu = async () => {
    try {
      const response = await fetch('/api/menu');
      const data = await response.json();
      setMenuItems(data.filter((item: MenuItem) => item.is_available));
    } catch (error) {
      console.error('Error fetching menu:', error);
    } finally {
      setLoading(false);
    }
  };

  const categories = ['All', ...Array.from(new Set(menuItems.map((item) => item.category)))];

  const filteredItems = selectedCategory === 'All' 
    ? menuItems 
    : menuItems.filter((item) => item.category === selectedCategory);

  const addToCart = (item: MenuItem) => {
    setCart((prev) => {
      const existing = prev.find((i) => i.id === String(item.id));
      if (existing) {
        return prev.map((i) =>
          i.id === String(item.id) ? { ...i, quantity: i.quantity + 1 } : i
        );
      }
      return [...prev, { id: String(item.id), name: item.name, price: item.price, quantity: 1 }];
    });
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart((prev) => {
      const updated = prev.map((item) =>
        item.id === id ? { ...item, quantity: Math.max(0, item.quantity + delta) } : item
      );
      return updated.filter((item) => item.quantity > 0);
    });
  };

  const totalAmount = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);

  const handleOrderSuccess = (orderNum: string) => {
    setOrderNumber(orderNum);
    setOrderSuccess(true);
    setShowCheckout(false);
    setCart([]);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-orange-50 via-white to-orange-50">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-orange-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600 text-lg">Loading menu...</p>
        </div>
      </div>
    );
  }

  if (orderSuccess) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-green-50 via-white to-green-50 p-4">
        <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full text-center">
          <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
            <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h2 className="text-3xl font-bold text-gray-900 mb-3">Order Placed!</h2>
          <p className="text-gray-600 mb-2">Your order number:</p>
          <p className="text-2xl font-bold text-orange-600 mb-6">{orderNumber}</p>
          <p className="text-gray-600 mb-8">Table {tableNumber}</p>
          <p className="text-sm text-gray-500 mb-6">Your order will be prepared shortly</p>
          <button
            onClick={() => {
              setOrderSuccess(false);
              window.location.reload();
            }}
            className="w-full bg-gradient-to-r from-orange-500 to-orange-600 text-white py-3 rounded-lg font-bold hover:from-orange-600 hover:to-orange-700 transition-all"
          >
            Order More
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-orange-50">
      <header className="bg-white shadow-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-3 sm:py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 sm:gap-3">
              <img 
                src="https://019c18bd-977d-7a24-957e-b7597cd8059d.mochausercontent.com/Gemini_Generated_Image_p3i1ggp3i1ggp3i1-(1)-(1).png" 
                alt="Yarana Cafe Kudwar" 
                className="h-10 w-10 sm:h-12 sm:w-12 object-contain"
              />
              <div>
                <h1 className="text-lg sm:text-2xl font-bold text-gray-900">Yarana Cafe</h1>
                <p className="text-xs sm:text-sm text-gray-600">Table {tableNumber}</p>
              </div>
            </div>
            <button
              onClick={() => setShowCheckout(true)}
              disabled={cart.length === 0}
              className="relative bg-orange-500 text-white px-4 sm:px-6 py-2 sm:py-3 rounded-lg font-bold hover:bg-orange-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg text-sm sm:text-base"
            >
              <ShoppingCart className="w-4 h-4 sm:w-5 sm:h-5 inline mr-1 sm:mr-2" />
              <span className="hidden xs:inline">Cart</span>
              {totalItems > 0 && (
                <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs font-bold rounded-full w-5 h-5 sm:w-6 sm:h-6 flex items-center justify-center">
                  {totalItems}
                </span>
              )}
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-6 py-2 rounded-full font-medium whitespace-nowrap transition-all ${
                selectedCategory === category
                  ? 'bg-orange-500 text-white shadow-md'
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 mb-24">
          {filteredItems.map((item) => {
            const inCart = cart.find((i) => i.id === String(item.id));
            return (
              <div
                key={item.id}
                className="bg-white rounded-xl sm:rounded-2xl shadow-md overflow-hidden hover:shadow-xl transition-all"
              >
                {item.image && (
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-full h-48 object-cover"
                  />
                )}
                <div className="p-5">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-900 mb-1">{item.name}</h3>
                      <div className="flex items-center gap-2 mb-2">
                        <span
                          className={`inline-block w-4 h-4 rounded-full border-2 ${
                            item.is_veg ? 'border-green-500' : 'border-red-500'
                          }`}
                        >
                          <span
                            className={`block w-2 h-2 rounded-full m-0.5 ${
                              item.is_veg ? 'bg-green-500' : 'bg-red-500'
                            }`}
                          />
                        </span>
                        <span className="text-sm text-gray-500">{item.category}</span>
                      </div>
                    </div>
                    <p className="text-2xl font-bold text-orange-600">₹{item.price}</p>
                  </div>
                  {item.description && (
                    <p className="text-sm text-gray-600 mb-4 line-clamp-2">{item.description}</p>
                  )}
                  {inCart ? (
                    <div className="flex items-center justify-between bg-orange-50 rounded-lg p-3">
                      <button
                        onClick={() => updateQuantity(String(item.id), -1)}
                        className="w-10 h-10 bg-orange-500 text-white rounded-full flex items-center justify-center hover:bg-orange-600 transition-all"
                      >
                        <Minus className="w-5 h-5" />
                      </button>
                      <span className="text-xl font-bold text-gray-900">{inCart.quantity}</span>
                      <button
                        onClick={() => updateQuantity(String(item.id), 1)}
                        className="w-10 h-10 bg-orange-500 text-white rounded-full flex items-center justify-center hover:bg-orange-600 transition-all"
                      >
                        <Plus className="w-5 h-5" />
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => addToCart(item)}
                      className="w-full bg-gradient-to-r from-orange-500 to-orange-600 text-white py-3 rounded-lg font-bold hover:from-orange-600 hover:to-orange-700 transition-all shadow-md"
                    >
                      Add to Cart
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {cart.length > 0 && (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-3 sm:p-4 shadow-2xl z-50">
          <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
            <div>
              <p className="text-xs sm:text-sm text-gray-600">{totalItems} items</p>
              <p className="text-xl sm:text-2xl font-bold text-gray-900">₹{totalAmount}</p>
            </div>
            <button
              onClick={() => setShowCheckout(true)}
              className="bg-gradient-to-r from-orange-500 to-orange-600 text-white px-6 sm:px-8 py-3 sm:py-4 rounded-lg font-bold text-base sm:text-lg hover:from-orange-600 hover:to-orange-700 transition-all shadow-lg whitespace-nowrap"
            >
              View Cart
            </button>
          </div>
        </div>
      )}

      <CheckoutModal
        isOpen={showCheckout}
        onClose={() => setShowCheckout(false)}
        cartItems={cart}
        onSuccess={handleOrderSuccess}
        orderType="table"
        tableNumber={tableNumber}
      />
    </div>
  );
}
