import { useState, useEffect } from 'react';
import { ShoppingCart, History, Phone, Mail } from 'lucide-react';
import { useNavigate } from 'react-router';
import { useAuth } from '@getmocha/users-service/react';
import { categories, MenuItem } from '@/data/menu';
import MenuCard from '@/react-app/components/MenuCard';
import CartDrawer from '@/react-app/components/CartDrawer';
import UserMenu from '@/react-app/components/UserMenu';
import CheckoutModal from '@/react-app/components/CheckoutModal';
import OrderSuccessModal from '@/react-app/components/OrderSuccessModal';

interface CartItem extends MenuItem {
  quantity: number;
}

export default function MenuPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isSuccessOpen, setIsSuccessOpen] = useState(false);
  const [orderNumber, setOrderNumber] = useState('');
  const [contactSettings, setContactSettings] = useState({
    phone_1: '+91 98765 43210',
    phone_2: '+91 98765 43211',
    email: 'info@yaranacafe.com',
  });

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const response = await fetch('/api/settings');
        const data = await response.json();
        setContactSettings(data);
      } catch (error) {
        console.error('Error fetching contact settings:', error);
      }
    };

    const fetchMenu = async () => {
      try {
        const response = await fetch('/api/menu');
        const data = await response.json();
        const formattedData = data.map((item: any) => ({
          id: String(item.id),
          name: item.name,
          description: item.description || '',
          price: item.price,
          category: item.category,
          image: item.image || '',
          isVeg: item.is_veg === 1,
          isAvailable: item.is_available === 1,
        }));
        setMenuItems(formattedData);
      } catch (error) {
        console.error('Error fetching menu:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchSettings();
    fetchMenu();
  }, []);

  const filteredItems = selectedCategory === 'All'
    ? menuItems.filter((item) => item.isAvailable)
    : menuItems.filter((item) => item.category === selectedCategory && item.isAvailable);

  const totalItems = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  const handleAddToCart = (item: MenuItem) => {
    setCartItems((prev) => {
      const existing = prev.find((i) => i.id === item.id);
      if (existing) {
        return prev.map((i) =>
          i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i
        );
      }
      return [...prev, { ...item, quantity: 1 }];
    });
  };

  const handleUpdateQuantity = (itemId: string, delta: number) => {
    setCartItems((prev) =>
      prev
        .map((item) =>
          item.id === itemId
            ? { ...item, quantity: Math.max(0, item.quantity + delta) }
            : item
        )
        .filter((item) => item.quantity > 0)
    );
  };

  const handleRemoveItem = (itemId: string) => {
    setCartItems((prev) => prev.filter((item) => item.id !== itemId));
  };

  const handleCheckout = () => {
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  const handleOrderSuccess = (orderNum: string) => {
    setOrderNumber(orderNum);
    setIsCheckoutOpen(false);
    setIsSuccessOpen(true);
    setCartItems([]);
  };

  const handleSuccessClose = () => {
    setIsSuccessOpen(false);
    setOrderNumber('');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-orange-50">
      {/* Header */}
      <header className="bg-white shadow-md sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img 
                src="https://019c18bd-977d-7a24-957e-b7597cd8059d.mochausercontent.com/Gemini_Generated_Image_p3i1ggp3i1ggp3i1-(1)-(1).png" 
                alt="Yarana Cafe Kudwar" 
                className="h-14 w-14 object-contain"
              />
              <h1 className="text-3xl font-bold bg-gradient-to-r from-orange-600 to-orange-500 bg-clip-text text-transparent">
                Yarana Cafe Kudwar
              </h1>
            </div>

            <div className="flex items-center gap-4">
              {/* Contact Information */}
              <div className="hidden lg:flex items-center gap-4 pr-4 border-r border-gray-200">
                <div className="flex items-center gap-2 text-sm">
                  <Phone className="w-4 h-4 text-orange-600" />
                  <div className="flex flex-col">
                    <a href={`tel:${contactSettings.phone_1.replace(/\s/g, '')}`} className="text-gray-700 hover:text-orange-600 transition-colors">
                      {contactSettings.phone_1}
                    </a>
                    <a href={`tel:${contactSettings.phone_2.replace(/\s/g, '')}`} className="text-gray-700 hover:text-orange-600 transition-colors">
                      {contactSettings.phone_2}
                    </a>
                  </div>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Mail className="w-4 h-4 text-orange-600" />
                  <a href={`mailto:${contactSettings.email}`} className="text-gray-700 hover:text-orange-600 transition-colors">
                    {contactSettings.email}
                  </a>
                </div>
              </div>
              {user && (
                <button
                  onClick={() => navigate('/orders')}
                  className="flex items-center gap-2 px-4 py-2 text-orange-600 hover:bg-orange-50 rounded-lg font-medium transition-colors"
                >
                  <History className="w-5 h-5" />
                  <span className="hidden sm:inline">Orders</span>
                </button>
              )}
              
              <UserMenu />
              
              <button
                onClick={() => setIsCartOpen(true)}
                className="relative p-2 hover:bg-orange-50 rounded-full transition-colors"
              >
                <ShoppingCart className="w-6 h-6 text-orange-600" />
                {totalItems > 0 && (
                  <span className="absolute -top-1 -right-1 bg-orange-600 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                    {totalItems}
                  </span>
                )}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Category Filter */}
      <div className="bg-white border-b border-gray-200 sticky top-[76px] z-20">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-6 py-2 rounded-full font-medium whitespace-nowrap transition-all ${
                  selectedCategory === category
                    ? 'bg-gradient-to-r from-orange-500 to-orange-600 text-white shadow-md'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Menu Grid */}
      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        {loading ? (
          <div className="text-center py-12">
            <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-orange-500"></div>
            <p className="mt-4 text-gray-600">Loading menu...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredItems.map((item) => (
              <MenuCard key={item.id} item={item} onAddToCart={handleAddToCart} />
            ))}
          </div>
        )}
      </main>

      {/* Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onCheckout={handleCheckout}
      />

      {/* Checkout Modal */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        cartItems={cartItems}
        onSuccess={handleOrderSuccess}
      />

      {/* Order Success Modal */}
      <OrderSuccessModal
        isOpen={isSuccessOpen}
        onClose={handleSuccessClose}
        orderNumber={orderNumber}
      />
    </div>
  );
}
