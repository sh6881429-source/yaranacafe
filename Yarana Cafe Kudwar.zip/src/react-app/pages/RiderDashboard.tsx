import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { Package, MapPin, Phone, Lock } from 'lucide-react';

interface Order {
  id: number;
  order_number: string;
  customer_name: string;
  customer_phone: string;
  customer_address: string;
  total_amount: number;
  status: string;
  rider_id: string | null;
  created_at: string;
  items: any[];
}

export default function RiderDashboard() {
  const navigate = useNavigate();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [riderId, setRiderId] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(false);



  // Auto-refresh orders every 5 seconds when authenticated
  useEffect(() => {
    if (!isAuthenticated || !riderId || !password) return;

    const interval = setInterval(() => {
      fetchOrders(riderId, password);
    }, 5000);

    return () => clearInterval(interval);
  }, [isAuthenticated, riderId, password]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!riderId) {
      setError('Please enter your rider ID');
      return;
    }

    if (!password) {
      setError('Please enter your password');
      return;
    }
    
    try {
      // Try to fetch orders with the given credentials
      const response = await fetch(`/api/rider/orders/${riderId}`, {
        headers: {
          'X-Rider-Password': password,
        },
      });

      if (!response.ok) {
        setError('Invalid rider ID or password');
        return;
      }

      setIsAuthenticated(true);
      fetchOrders(riderId, password);
      setError('');
    } catch (error) {
      setError('Login failed. Please try again.');
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setRiderId('');
    setPassword('');
  };

  const fetchOrders = async (currentRiderId: string, riderPassword: string) => {
    setLoading(true);
    try {
      const response = await fetch(`/api/rider/orders/${currentRiderId}`, {
        headers: {
          'X-Rider-Password': riderPassword,
        },
      });
      const data = await response.json();
      setOrders(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error('Error fetching orders:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateOrderStatus = async (orderId: number, status: string) => {
    try {
      await fetch(`/api/rider/orders/${orderId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          status, 
          rider_id: riderId,
          riderId,
          riderPassword: password,
        }),
      });
      fetchOrders(riderId, password);
    } catch (error) {
      console.error('Error updating order:', error);
    }
  };

  const acceptOrder = async (orderId: number) => {
    try {
      await fetch(`/api/rider/orders/${orderId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          rider_id: riderId, 
          status: 'picked_up',
          riderId,
          riderPassword: password,
        }),
      });
      fetchOrders(riderId, password);
    } catch (error) {
      console.error('Error accepting order:', error);
    }
  };

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      pending: 'bg-yellow-100 text-yellow-800',
      confirmed: 'bg-blue-100 text-blue-800',
      preparing: 'bg-orange-100 text-orange-800',
      ready: 'bg-purple-100 text-purple-800',
      picked_up: 'bg-indigo-100 text-indigo-800',
      delivered: 'bg-green-100 text-green-800',
      cancelled: 'bg-red-100 text-red-800',
    };
    return colors[status] || 'bg-gray-100 text-gray-800';
  };

  // Login screen
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-white to-blue-50">
        <div className="bg-white p-8 rounded-2xl shadow-xl border border-gray-200 w-full max-w-md">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <Lock className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900">Rider Login</h2>
            <p className="text-gray-600 mt-2">Yarana Cafe Kudwar</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Rider ID</label>
              <input
                type="text"
                value={riderId}
                onChange={(e) => setRiderId(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter your rider ID"
                autoFocus
              />
              <p className="text-xs text-gray-500 mt-1">Contact admin to get your rider ID</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter password"
              />
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
                {error}
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-gradient-to-r from-blue-500 to-blue-600 text-white py-3 rounded-lg font-medium hover:from-blue-600 hover:to-blue-700 transition-all shadow-md"
            >
              Login
            </button>

            <button
              type="button"
              onClick={() => navigate('/')}
              className="w-full bg-gray-100 text-gray-700 py-3 rounded-lg font-medium hover:bg-gray-200 transition-colors"
            >
              Back to Menu
            </button>
          </form>
        </div>
      </div>
    );
  }

  // Main dashboard
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-white to-blue-50">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600 text-lg">Loading orders...</p>
        </div>
      </div>
    );
  }

  const myOrders = orders.filter((o) => o.rider_id === riderId);
  const availableOrders = orders.filter((o) => !o.rider_id && o.status === 'ready');

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50">
      <header className="bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img 
                src="https://019c18bd-977d-7a24-957e-b7597cd8059d.mochausercontent.com/Gemini_Generated_Image_p3i1ggp3i1ggp3i1-(1)-(1).png" 
                alt="Yarana Cafe Kudwar" 
                className="h-12 w-12 object-contain"
              />
              <div>
                <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-blue-500 bg-clip-text text-transparent">
                  Rider Dashboard
                </h1>
                <p className="text-sm text-gray-600 mt-1">Yarana Cafe Kudwar</p>
              </div>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => navigate('/')}
                className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200 transition-colors"
              >
                Back to Menu
              </button>
              <button
                onClick={handleLogout}
                className="px-4 py-2 bg-red-100 text-red-700 rounded-lg font-medium hover:bg-red-200 transition-colors"
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h2 className="text-xl font-bold text-gray-900 mb-4">My Deliveries ({myOrders.length})</h2>
            <div className="space-y-4">
              {myOrders.length === 0 ? (
                <div className="bg-white rounded-xl p-8 text-center text-gray-500">
                  <Package className="w-12 h-12 mx-auto mb-2 text-gray-300" />
                  <p>No active deliveries</p>
                </div>
              ) : (
                myOrders.map((order) => (
                  <div key={order.id} className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="text-lg font-bold text-gray-900">{order.order_number}</h3>
                          <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                            (order as any).order_type === 'table' 
                              ? 'bg-blue-100 text-blue-700' 
                              : 'bg-green-100 text-green-700'
                          }`}>
                            {(order as any).order_type === 'table' ? `Table ${(order as any).table_number}` : 'Delivery'}
                          </span>
                        </div>
                        <p className="text-gray-600">{order.customer_name}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xl font-bold text-blue-600 mb-1">₹{order.total_amount}</p>
                        <span className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(order.status)}`}>
                          {order.status.replace('_', ' ').toUpperCase()}
                        </span>
                      </div>
                    </div>

                    {(order as any).paid_amount && (
                      <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-4">
                        <div className="grid grid-cols-2 gap-3 text-sm">
                          <div>
                            <p className="text-gray-600">Paid Amount</p>
                            <p className="font-bold text-green-600">₹{(order as any).paid_amount}</p>
                          </div>
                          <div>
                            <p className="text-gray-600">UTR Number</p>
                            <p className="font-mono text-xs font-medium">{(order as any).utr_number}</p>
                          </div>
                          {(order as any).payment_option === 'advance' && (
                            <>
                              <div>
                                <p className="text-gray-600">Payment Type</p>
                                <p className="font-medium">₹50 Advance</p>
                              </div>
                              <div>
                                <p className="text-gray-600">Collect on Delivery</p>
                                <p className="font-bold text-orange-600">₹{order.total_amount - 50}</p>
                              </div>
                            </>
                          )}
                          {(order as any).payment_option === 'full' && (
                            <div className="col-span-2">
                              <p className="text-gray-600">Payment Type</p>
                              <p className="font-medium text-green-600">✓ Full Payment Complete</p>
                            </div>
                          )}
                          <div className="col-span-2">
                            <p className="text-gray-600">Verification Status</p>
                            <p className={`font-medium ${(order as any).is_payment_verified ? 'text-green-600' : 'text-orange-600'}`}>
                              {(order as any).is_payment_verified ? '✓ Verified by Admin' : '⚠ Pending Verification'}
                            </p>
                          </div>
                        </div>
                      </div>
                    )}

                    <div className="space-y-2 mb-4">
                      <div className="flex items-start gap-2">
                        <MapPin className="w-5 h-5 text-gray-400 mt-0.5" />
                        <p className="text-sm text-gray-700">{order.customer_address}</p>
                      </div>
                      {order.customer_phone && (
                        <div className="flex items-center gap-2">
                          <Phone className="w-5 h-5 text-gray-400" />
                          <a href={`tel:${order.customer_phone}`} className="text-sm text-blue-600 hover:underline">
                            {order.customer_phone}
                          </a>
                        </div>
                      )}
                    </div>

                    <div className="border-t border-gray-200 pt-3 mb-4">
                      <p className="text-sm text-gray-500 mb-2">Items:</p>
                      {order.items.map((item: any) => (
                        <div key={item.id} className="flex justify-between text-sm text-gray-600 mb-1">
                          <span>{item.item_name} x{item.quantity}</span>
                          <span>₹{item.item_price * item.quantity}</span>
                        </div>
                      ))}
                      <div className="border-t border-gray-200 mt-2 pt-2 flex justify-between font-bold">
                        <span>Total</span>
                        <span className="text-blue-600">₹{order.total_amount}</span>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      {order.status === 'picked_up' && (
                        <button
                          onClick={() => updateOrderStatus(order.id, 'delivered')}
                          className="flex-1 bg-gradient-to-r from-green-500 to-green-600 text-white py-2 rounded-lg font-medium hover:from-green-600 hover:to-green-700 transition-all"
                        >
                          Mark as Delivered
                        </button>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          <div>
            <h2 className="text-xl font-bold text-gray-900 mb-4">Available Orders ({availableOrders.length})</h2>
            <div className="space-y-4">
              {availableOrders.length === 0 ? (
                <div className="bg-white rounded-xl p-8 text-center text-gray-500">
                  <Package className="w-12 h-12 mx-auto mb-2 text-gray-300" />
                  <p>No orders available</p>
                </div>
              ) : (
                availableOrders.map((order) => (
                  <div key={order.id} className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-lg font-bold text-gray-900">{order.order_number}</h3>
                        <p className="text-gray-600">{order.customer_name}</p>
                      </div>
                      <p className="text-xl font-bold text-blue-600">₹{order.total_amount}</p>
                    </div>

                    {(order as any).paid_amount && (
                      <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4 text-sm">
                        <div className="flex justify-between mb-1">
                          <span className="text-gray-600">Paid:</span>
                          <span className="font-bold text-green-600">₹{(order as any).paid_amount}</span>
                        </div>
                        {(order as any).payment_option === 'advance' && (
                          <div className="flex justify-between">
                            <span className="text-gray-600">Collect COD:</span>
                            <span className="font-bold text-orange-600">₹{order.total_amount - 50}</span>
                          </div>
                        )}
                      </div>
                    )}

                    <div className="flex items-start gap-2 mb-4">
                      <MapPin className="w-5 h-5 text-gray-400 mt-0.5" />
                      <p className="text-sm text-gray-700">{order.customer_address}</p>
                    </div>

                    <div className="border-t border-gray-200 pt-3 mb-4">
                      <p className="text-xs text-gray-500 mb-2">Order Items:</p>
                      {order.items.map((item: any) => (
                        <div key={item.id} className="text-sm text-gray-600">
                          {item.item_name} x{item.quantity}
                        </div>
                      ))}
                    </div>

                    <button
                      onClick={() => acceptOrder(order.id)}
                      className="w-full bg-gradient-to-r from-blue-500 to-blue-600 text-white py-2 rounded-lg font-medium hover:from-blue-600 hover:to-blue-700 transition-all"
                    >
                      Accept Delivery
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
