import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { Package, Users, Lock, Plus, X, Settings as SettingsIcon, UtensilsCrossed, Edit2, Trash2, UserCog, QrCode } from 'lucide-react';

interface Order {
  id: number;
  order_number: string;
  customer_name: string;
  customer_phone: string;
  customer_address: string;
  total_amount: number;
  status: string;
  rider_id: string | null;
  created_at: string;
  items: any[];
}

interface User {
  id: string;
  email: string;
  name: string;
  phone: string;
  role: string;
  is_active: number;
  password?: string;
}

export default function AdminDashboard() {
  const navigate = useNavigate();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState<'orders' | 'customers' | 'staff' | 'menu' | 'settings'>('orders');
  const [orders, setOrders] = useState<Order[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(false);
  const [showCreateRider, setShowCreateRider] = useState(false);
  const [newRider, setNewRider] = useState({
    name: '',
    user_id: '',
    phone: '',
    password: '',
  });
  const [createError, setCreateError] = useState('');
  const [settings, setSettings] = useState({
    phone_1: '',
    phone_2: '',
    email: '',
    minimum_order_amount: '0',
    payment_qr_url: '',
  });
  const [editingPassword, setEditingPassword] = useState<string | null>(null);
  const [newPassword, setNewPassword] = useState('');
  const [menuItems, setMenuItems] = useState<any[]>([]);
  const [showCreateMenuItem, setShowCreateMenuItem] = useState(false);
  const [editingMenuItem, setEditingMenuItem] = useState<any | null>(null);
  const [menuForm, setMenuForm] = useState({
    name: '',
    description: '',
    price: '',
    category: 'Main Course',
    image: '',
    is_veg: true,
    is_available: true,
  });



  // Auto-refresh orders every 5 seconds when authenticated (but not while editing)
  useEffect(() => {
    if (!isAuthenticated) return;

    // Don't auto-refresh if user is actively editing
    if (selectedUser !== null || editingPassword !== null || showCreateRider) return;

    const interval = setInterval(() => {
      if (activeTab === 'orders') {
        fetchOrders();
      }
      // Don't auto-refresh users tab to avoid interrupting edits
    }, 5000);

    return () => clearInterval(interval);
  }, [isAuthenticated, activeTab, selectedUser, editingPassword, showCreateRider]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === 'Yaranacafe8948') {
      setIsAuthenticated(true);
      fetchOrders();
      fetchUsers();
      fetchSettings();
      fetchMenuItems();
      setError('');
    } else {
      setError('Incorrect password');
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setPassword('');
  };

  const fetchOrders = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/admin/orders', {
        headers: {
          'X-Admin-Password': 'Yaranacafe8948',
        },
      });
      const data = await response.json();
      setOrders(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error('Error fetching orders:', error);
      setOrders([]);
    } finally {
      setLoading(false);
    }
  };

  const fetchUsers = async () => {
    try {
      const response = await fetch('/api/admin/users', {
        headers: {
          'X-Admin-Password': 'Yaranacafe8948',
        },
      });
      const data = await response.json();
      setUsers(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error('Error fetching users:', error);
      setUsers([]);
    }
  };

  const fetchSettings = async () => {
    try {
      const response = await fetch('/api/settings');
      const data = await response.json();
      setSettings(data);
    } catch (error) {
      console.error('Error fetching settings:', error);
    }
  };

  const fetchMenuItems = async () => {
    try {
      const response = await fetch('/api/menu');
      const data = await response.json();
      setMenuItems(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error('Error fetching menu:', error);
      setMenuItems([]);
    }
  };

  const createMenuItem = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await fetch('/api/menu', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...menuForm,
          price: parseInt(menuForm.price),
          admin_password: 'Yaranacafe8948',
        }),
      });
      fetchMenuItems();
      setShowCreateMenuItem(false);
      setMenuForm({
        name: '',
        description: '',
        price: '',
        category: 'Main Course',
        image: '',
        is_veg: true,
        is_available: true,
      });
    } catch (error) {
      console.error('Error creating menu item:', error);
    }
  };

  const updateMenuItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingMenuItem) return;
    try {
      await fetch(`/api/menu/${editingMenuItem.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...menuForm,
          price: parseInt(menuForm.price),
          admin_password: 'Yaranacafe8948',
        }),
      });
      fetchMenuItems();
      setEditingMenuItem(null);
      setMenuForm({
        name: '',
        description: '',
        price: '',
        category: 'Main Course',
        image: '',
        is_veg: true,
        is_available: true,
      });
    } catch (error) {
      console.error('Error updating menu item:', error);
    }
  };

  const deleteMenuItem = async (itemId: number) => {
    if (!confirm('Are you sure you want to delete this menu item?')) return;
    try {
      await fetch(`/api/menu/${itemId}`, {
        method: 'DELETE',
        headers: {
          'X-Admin-Password': 'Yaranacafe8948',
        },
      });
      fetchMenuItems();
    } catch (error) {
      console.error('Error deleting menu item:', error);
    }
  };

  const startEditMenuItem = (item: any) => {
    setEditingMenuItem(item);
    setMenuForm({
      name: item.name,
      description: item.description || '',
      price: String(item.price),
      category: item.category,
      image: item.image || '',
      is_veg: item.is_veg === 1,
      is_available: item.is_available === 1,
    });
  };

  const updateSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await fetch('/api/settings', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          ...settings, 
          minimum_order_amount: parseInt(settings.minimum_order_amount) || 0,
          admin_password: 'Yaranacafe8948' 
        }),
      });
      alert('Settings updated successfully!');
    } catch (error) {
      console.error('Error updating settings:', error);
      alert('Failed to update settings');
    }
  };

  const verifyPayment = async (orderId: number) => {
    try {
      await fetch(`/api/admin/orders/${orderId}/verify-payment`, {
        method: 'PATCH',
        headers: {
          'X-Admin-Password': 'Yaranacafe8948',
        },
      });
      fetchOrders();
      alert('Payment verified successfully!');
    } catch (error) {
      console.error('Error verifying payment:', error);
      alert('Failed to verify payment');
    }
  };

  const updateOrderStatus = async (orderId: number, status: string, riderId?: string) => {
    try {
      await fetch(`/api/admin/orders/${orderId}`, {
        method: 'PATCH',
        headers: { 
          'Content-Type': 'application/json',
          'X-Admin-Password': 'Yaranacafe8948',
        },
        body: JSON.stringify({ status, rider_id: riderId }),
      });
      fetchOrders();
    } catch (error) {
      console.error('Error updating order:', error);
    }
  };

  const updateUser = async (userId: string, updates: Partial<User & { password?: string }>) => {
    try {
      await fetch(`/api/users/${userId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...updates, admin_password: 'Yaranacafe8948' }),
      });
      fetchUsers();
      setSelectedUser(null);
      setEditingPassword(null);
      setNewPassword('');
    } catch (error) {
      console.error('Error updating user:', error);
    }
  };

  const deleteUser = async (userId: string) => {
    if (!confirm('Are you sure you want to delete this user? This action cannot be undone.')) return;
    
    try {
      const response = await fetch(`/api/users/${userId}`, {
        method: 'DELETE',
        headers: {
          'X-Admin-Password': 'Yaranacafe8948',
        },
      });

      if (!response.ok) {
        const error = await response.json();
        alert(error.error || 'Failed to delete user');
        return;
      }

      fetchUsers();
    } catch (error) {
      console.error('Error deleting user:', error);
      alert('Failed to delete user');
    }
  };

  const createRider = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreateError('');

    if (!newRider.name || !newRider.user_id || !newRider.phone || !newRider.password) {
      setCreateError('All fields are required');
      return;
    }

    try {
      const response = await fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...newRider,
          role: 'rider',
          admin_password: 'Yaranacafe8948',
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        setCreateError(error.error || 'Failed to create rider');
        return;
      }

      fetchUsers();
      setShowCreateRider(false);
      setNewRider({ name: '', user_id: '', phone: '', password: '' });
    } catch (error) {
      console.error('Error creating rider:', error);
      setCreateError('Failed to create rider');
    }
  };

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      pending: 'bg-yellow-100 text-yellow-800',
      confirmed: 'bg-blue-100 text-blue-800',
      preparing: 'bg-orange-100 text-orange-800',
      ready: 'bg-purple-100 text-purple-800',
      picked_up: 'bg-indigo-100 text-indigo-800',
      delivered: 'bg-green-100 text-green-800',
      cancelled: 'bg-red-100 text-red-800',
    };
    return colors[status] || 'bg-gray-100 text-gray-800';
  };

  const customers = users.filter((u) => u.role === 'customer');
  const staff = users.filter((u) => u.role === 'admin' || u.role === 'rider');
  const riders = users.filter((u) => u.role === 'rider');

  // Login screen
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-50 via-white to-purple-50">
        <div className="bg-white p-8 rounded-2xl shadow-xl border border-gray-200 w-full max-w-md">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <Lock className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900">Admin Login</h2>
            <p className="text-gray-600 mt-2">Yarana Cafe Kudwar</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="Enter admin password"
                autoFocus
              />
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
                {error}
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-gradient-to-r from-purple-500 to-purple-600 text-white py-3 rounded-lg font-medium hover:from-purple-600 hover:to-purple-700 transition-all shadow-md"
            >
              Login
            </button>

            <button
              type="button"
              onClick={() => navigate('/')}
              className="w-full bg-gray-100 text-gray-700 py-3 rounded-lg font-medium hover:bg-gray-200 transition-colors"
            >
              Back to Menu
            </button>
          </form>
        </div>
      </div>
    );
  }

  // Main dashboard
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-50 via-white to-purple-50">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600 text-lg">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-purple-50">
      <header className="bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img 
                src="https://019c18bd-977d-7a24-957e-b7597cd8059d.mochausercontent.com/Gemini_Generated_Image_p3i1ggp3i1ggp3i1-(1)-(1).png" 
                alt="Yarana Cafe Kudwar" 
                className="h-12 w-12 object-contain"
              />
              <div>
                <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-purple-500 bg-clip-text text-transparent">
                  Admin Dashboard
                </h1>
                <p className="text-sm text-gray-600 mt-1">Yarana Cafe Kudwar</p>
              </div>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => navigate('/admin/qr')}
                className="px-4 py-2 bg-orange-100 text-orange-700 rounded-lg font-medium hover:bg-orange-200 transition-colors flex items-center gap-2"
              >
                <QrCode className="w-4 h-4" />
                <span className="hidden sm:inline">Table QR Codes</span>
              </button>
              <button
                onClick={() => navigate('/')}
                className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200 transition-colors"
              >
                Back to Menu
              </button>
              <button
                onClick={handleLogout}
                className="px-4 py-2 bg-red-100 text-red-700 rounded-lg font-medium hover:bg-red-200 transition-colors"
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
        <div className="flex gap-4 mb-6 overflow-x-auto">
          <button
            onClick={() => setActiveTab('orders')}
            className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-all whitespace-nowrap ${
              activeTab === 'orders'
                ? 'bg-gradient-to-r from-purple-500 to-purple-600 text-white shadow-md'
                : 'bg-white text-gray-700 hover:bg-gray-50'
            }`}
          >
            <Package className="w-5 h-5" />
            Orders ({orders.length})
          </button>
          <button
            onClick={() => setActiveTab('customers')}
            className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-all whitespace-nowrap ${
              activeTab === 'customers'
                ? 'bg-gradient-to-r from-purple-500 to-purple-600 text-white shadow-md'
                : 'bg-white text-gray-700 hover:bg-gray-50'
            }`}
          >
            <Users className="w-5 h-5" />
            Customers ({customers.length})
          </button>
          <button
            onClick={() => setActiveTab('staff')}
            className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-all whitespace-nowrap ${
              activeTab === 'staff'
                ? 'bg-gradient-to-r from-purple-500 to-purple-600 text-white shadow-md'
                : 'bg-white text-gray-700 hover:bg-gray-50'
            }`}
          >
            <UserCog className="w-5 h-5" />
            Staff ({staff.length})
          </button>
          <button
            onClick={() => setActiveTab('menu')}
            className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-all whitespace-nowrap ${
              activeTab === 'menu'
                ? 'bg-gradient-to-r from-purple-500 to-purple-600 text-white shadow-md'
                : 'bg-white text-gray-700 hover:bg-gray-50'
            }`}
          >
            <UtensilsCrossed className="w-5 h-5" />
            Menu ({menuItems.length})
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-all whitespace-nowrap ${
              activeTab === 'settings'
                ? 'bg-gradient-to-r from-purple-500 to-purple-600 text-white shadow-md'
                : 'bg-white text-gray-700 hover:bg-gray-50'
            }`}
          >
            <SettingsIcon className="w-5 h-5" />
            Settings
          </button>
        </div>

        {activeTab === 'orders' && (
          <div className="grid gap-4">
            {orders.map((order) => (
              <div key={order.id} className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="text-xl font-bold text-gray-900">{order.order_number}</h3>
                      <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                        (order as any).order_type === 'table' 
                          ? 'bg-blue-100 text-blue-700' 
                          : 'bg-green-100 text-green-700'
                      }`}>
                        {(order as any).order_type === 'table' ? `Table ${(order as any).table_number}` : 'Delivery'}
                      </span>
                    </div>
                    <p className="text-gray-600 mt-1">{order.customer_name}</p>
                    <p className="text-sm text-gray-500">{new Date(order.created_at).toLocaleString()}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-purple-600">₹{order.total_amount}</p>
                    <span className={`inline-block px-3 py-1 rounded-full text-sm font-medium mt-2 ${getStatusColor(order.status)}`}>
                      {order.status.replace('_', ' ').toUpperCase()}
                    </span>
                  </div>
                </div>

                {(order as any).order_type === 'delivery' && (order as any).paid_amount && (
                  <div className="bg-orange-50 border border-orange-200 rounded-lg p-4 mb-4">
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <p className="text-sm text-gray-600">Payment Status</p>
                        <p className="font-bold text-gray-900">
                          {(order as any).is_payment_verified ? (
                            <span className="text-green-600">✓ Verified</span>
                          ) : (
                            <span className="text-orange-600">⚠ Pending Verification</span>
                          )}
                        </p>
                      </div>
                      {!(order as any).is_payment_verified && (
                        <button
                          onClick={() => verifyPayment(order.id)}
                          className="px-4 py-2 bg-green-500 text-white rounded-lg font-medium hover:bg-green-600 transition-all"
                        >
                          Verify Payment
                        </button>
                      )}
                    </div>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-gray-500">Paid Amount</p>
                        <p className="font-bold text-green-600">₹{(order as any).paid_amount}</p>
                      </div>
                      <div>
                        <p className="text-gray-500">UTR Number</p>
                        <p className="font-mono font-medium">{(order as any).utr_number}</p>
                      </div>
                      <div>
                        <p className="text-gray-500">Payment Type</p>
                        <p className="font-medium">
                          {(order as any).payment_option === 'advance' ? '₹50 Advance' : 'Full Payment'}
                        </p>
                      </div>
                      {(order as any).payment_option === 'advance' && (
                        <div>
                          <p className="text-gray-500">COD Amount</p>
                          <p className="font-bold text-orange-600">₹{order.total_amount - 50}</p>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <p className="text-sm text-gray-500">Phone</p>
                    <p className="font-medium">{order.customer_phone || 'Not provided'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Address</p>
                    <p className="font-medium">{order.customer_address}</p>
                  </div>
                </div>

                <div className="border-t border-gray-200 pt-4 mb-4">
                  <p className="text-sm font-semibold text-gray-700 mb-2">Items:</p>
                  {order.items.map((item: any) => (
                    <div key={item.id} className="flex justify-between text-sm text-gray-600 mb-1">
                      <span>{item.item_name} x{item.quantity}</span>
                      <span>₹{item.item_price * item.quantity}</span>
                    </div>
                  ))}
                </div>

                <div className="flex gap-2">
                  <select
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    value={order.status}
                    onChange={(e) => updateOrderStatus(order.id, e.target.value, order.rider_id || undefined)}
                  >
                    <option value="pending">Pending</option>
                    <option value="confirmed">Confirmed</option>
                    <option value="preparing">Preparing</option>
                    <option value="ready">Ready</option>
                    <option value="picked_up">Picked Up</option>
                    <option value="delivered">Delivered</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                  
                  {(order as any).order_type === 'delivery' && (
                    <select
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      value={order.rider_id || ''}
                      onChange={(e) => updateOrderStatus(order.id, order.status, e.target.value || undefined)}
                    >
                      <option value="">Assign Rider</option>
                      {riders.map((rider) => (
                        <option key={rider.id} value={rider.id}>
                          {rider.name}
                        </option>
                      ))}
                    </select>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'customers' && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200">
              <h2 className="text-xl font-bold text-gray-900">Customer List</h2>
              <p className="text-sm text-gray-600 mt-1">Customers who have placed orders</p>
            </div>
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Phone</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Address</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {customers.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="px-6 py-12 text-center text-gray-500">
                      No customers yet
                    </td>
                  </tr>
                ) : (
                  customers.map((user) => (
                    <tr key={user.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className="font-medium text-gray-900">{user.name}</span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">{user.email}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">{user.phone || 'Not set'}</td>
                      <td className="px-6 py-4 text-sm text-gray-600">{(user as any).address || 'Not set'}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}

        {activeTab === 'staff' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-xl font-bold text-gray-900">Staff Management</h2>
                <p className="text-sm text-gray-600 mt-1">Manage admins and delivery riders</p>
              </div>
              <button
                onClick={() => setShowCreateRider(true)}
                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-500 to-purple-600 text-white rounded-lg font-medium hover:from-purple-600 hover:to-purple-700 transition-all shadow-md"
              >
                <Plus className="w-5 h-5" />
                Create New Rider
              </button>
            </div>

            {showCreateRider && (
              <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-purple-200">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-bold text-gray-900">Create New Rider</h3>
                  <button
                    onClick={() => {
                      setShowCreateRider(false);
                      setNewRider({ name: '', user_id: '', phone: '', password: '' });
                      setCreateError('');
                    }}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <form onSubmit={createRider} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Name *</label>
                    <input
                      type="text"
                      value={newRider.name}
                      onChange={(e) => setNewRider({ ...newRider, name: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      placeholder="Enter rider name"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">User ID *</label>
                    <input
                      type="text"
                      value={newRider.user_id}
                      onChange={(e) => setNewRider({ ...newRider, user_id: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      placeholder="rider001"
                      required
                    />
                    <p className="text-xs text-gray-500 mt-1">This will be used for login (e.g., rider001, rider002)</p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Phone *</label>
                    <input
                      type="tel"
                      value={newRider.phone}
                      onChange={(e) => setNewRider({ ...newRider, phone: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      placeholder="+91 98765 43210"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Password *</label>
                    <input
                      type="text"
                      value={newRider.password}
                      onChange={(e) => setNewRider({ ...newRider, password: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      placeholder="Set rider password"
                      required
                    />
                    <p className="text-xs text-gray-500 mt-1">Rider will use this password to login</p>
                  </div>

                  {createError && (
                    <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
                      {createError}
                    </div>
                  )}

                  <div className="flex gap-2">
                    <button
                      type="submit"
                      className="flex-1 bg-gradient-to-r from-purple-500 to-purple-600 text-white py-2 rounded-lg font-medium hover:from-purple-600 hover:to-purple-700 transition-all"
                    >
                      Create Rider
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setShowCreateRider(false);
                        setNewRider({ name: '', user_id: '', phone: '', password: '' });
                        setCreateError('');
                      }}
                      className="px-6 bg-gray-100 text-gray-700 py-2 rounded-lg font-medium hover:bg-gray-200 transition-colors"
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              </div>
            )}

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">User ID</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Phone</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Role</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Password</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {staff.map((user) => (
                    <tr key={user.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        {selectedUser?.id === user.id ? (
                          <input
                            type="text"
                            defaultValue={user.name}
                            className="px-2 py-1 border border-gray-300 rounded"
                            onBlur={(e) => {
                              if (e.target.value !== user.name) {
                                updateUser(user.id, { name: e.target.value, phone: user.phone, role: user.role });
                              }
                            }}
                          />
                        ) : (
                          <span className="font-medium text-gray-900">{user.name}</span>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600 font-mono">{user.id}</td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {selectedUser?.id === user.id ? (
                          <input
                            type="text"
                            defaultValue={user.phone || ''}
                            placeholder="Phone number"
                            className="px-2 py-1 border border-gray-300 rounded w-full"
                            onBlur={(e) => {
                              if (e.target.value !== user.phone) {
                                updateUser(user.id, { name: user.name, phone: e.target.value, role: user.role });
                              }
                            }}
                          />
                        ) : (
                          <span className="text-sm text-gray-600">{user.phone || 'Not set'}</span>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                          user.role === 'admin' ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'
                        }`}>
                          {user.role.toUpperCase()}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {editingPassword === user.id ? (
                          <div className="flex gap-1">
                            <input
                              type="text"
                              value={newPassword}
                              onChange={(e) => setNewPassword(e.target.value)}
                              placeholder="New password"
                              className="px-2 py-1 border border-gray-300 rounded text-sm w-32"
                            />
                            <button
                              onClick={() => {
                                if (newPassword) {
                                  updateUser(user.id, { 
                                    name: user.name, 
                                    phone: user.phone, 
                                    role: user.role,
                                    password: newPassword 
                                  });
                                }
                              }}
                              className="text-green-600 hover:text-green-800 font-medium text-sm"
                            >
                              Save
                            </button>
                            <button
                              onClick={() => {
                                setEditingPassword(null);
                                setNewPassword('');
                              }}
                              className="text-gray-600 hover:text-gray-800 font-medium text-sm"
                            >
                              Cancel
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => setEditingPassword(user.id)}
                            className="text-blue-600 hover:text-blue-800 font-medium text-sm"
                          >
                            {user.password ? 'Change' : 'Set'} Password
                          </button>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex gap-2">
                          <button
                            onClick={() => setSelectedUser(selectedUser?.id === user.id ? null : user)}
                            className="text-purple-600 hover:text-purple-800 font-medium text-sm"
                          >
                            {selectedUser?.id === user.id ? 'Done' : 'Edit'}
                          </button>
                          {user.role === 'rider' && (
                            <button
                              onClick={() => deleteUser(user.id)}
                              className="text-red-600 hover:text-red-800 font-medium text-sm"
                            >
                              Delete
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'menu' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-bold text-gray-900">Manage Menu</h2>
              <button
                onClick={() => setShowCreateMenuItem(true)}
                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-500 to-purple-600 text-white rounded-lg font-medium hover:from-purple-600 hover:to-purple-700 transition-all shadow-md"
              >
                <Plus className="w-5 h-5" />
                Add Menu Item
              </button>
            </div>

            {(showCreateMenuItem || editingMenuItem) && (
              <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-purple-200">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-bold text-gray-900">
                    {editingMenuItem ? 'Edit Menu Item' : 'Add New Menu Item'}
                  </h3>
                  <button
                    onClick={() => {
                      setShowCreateMenuItem(false);
                      setEditingMenuItem(null);
                      setMenuForm({
                        name: '',
                        description: '',
                        price: '',
                        category: 'Main Course',
                        image: '',
                        is_veg: true,
                        is_available: true,
                      });
                    }}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <form onSubmit={editingMenuItem ? updateMenuItem : createMenuItem} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Name *</label>
                      <input
                        type="text"
                        value={menuForm.name}
                        onChange={(e) => setMenuForm({ ...menuForm, name: e.target.value })}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                        placeholder="Butter Chicken"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Category *</label>
                      <select
                        value={menuForm.category}
                        onChange={(e) => setMenuForm({ ...menuForm, category: e.target.value })}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                        required
                      >
                        <option value="Starters">Starters</option>
                        <option value="Main Course">Main Course</option>
                        <option value="Rice">Rice</option>
                        <option value="Bread">Bread</option>
                        <option value="Desserts">Desserts</option>
                        <option value="Beverages">Beverages</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                    <textarea
                      value={menuForm.description}
                      onChange={(e) => setMenuForm({ ...menuForm, description: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      placeholder="A delicious dish made with..."
                      rows={2}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Price (₹) *</label>
                      <input
                        type="number"
                        value={menuForm.price}
                        onChange={(e) => setMenuForm({ ...menuForm, price: e.target.value })}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                        placeholder="280"
                        required
                        min="0"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Image URL</label>
                      <input
                        type="url"
                        value={menuForm.image}
                        onChange={(e) => setMenuForm({ ...menuForm, image: e.target.value })}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                        placeholder="https://images.unsplash.com/..."
                      />
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <label className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={menuForm.is_veg}
                        onChange={(e) => setMenuForm({ ...menuForm, is_veg: e.target.checked })}
                        className="w-4 h-4 text-purple-600 border-gray-300 rounded focus:ring-purple-500"
                      />
                      <span className="text-sm font-medium text-gray-700">Vegetarian</span>
                    </label>

                    <label className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={menuForm.is_available}
                        onChange={(e) => setMenuForm({ ...menuForm, is_available: e.target.checked })}
                        className="w-4 h-4 text-purple-600 border-gray-300 rounded focus:ring-purple-500"
                      />
                      <span className="text-sm font-medium text-gray-700">Available</span>
                    </label>
                  </div>

                  <div className="flex gap-2">
                    <button
                      type="submit"
                      className="flex-1 bg-gradient-to-r from-purple-500 to-purple-600 text-white py-2 rounded-lg font-medium hover:from-purple-600 hover:to-purple-700 transition-all"
                    >
                      {editingMenuItem ? 'Update Item' : 'Add Item'}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setShowCreateMenuItem(false);
                        setEditingMenuItem(null);
                        setMenuForm({
                          name: '',
                          description: '',
                          price: '',
                          category: 'Main Course',
                          image: '',
                          is_veg: true,
                          is_available: true,
                        });
                      }}
                      className="px-6 bg-gray-100 text-gray-700 py-2 rounded-lg font-medium hover:bg-gray-200 transition-colors"
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {menuItems.map((item) => (
                <div key={item.id} className="bg-white rounded-xl p-4 shadow-sm border border-gray-200 hover:shadow-md transition-shadow">
                  <div className="flex items-start gap-3">
                    {item.image && (
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-20 h-20 object-cover rounded-lg"
                      />
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <h3 className="font-bold text-gray-900 truncate">{item.name}</h3>
                          <span className={`inline-block w-3 h-3 rounded-full ${item.is_veg ? 'bg-green-500' : 'bg-red-500'}`} />
                        </div>
                        <p className="font-bold text-purple-600 whitespace-nowrap">₹{item.price}</p>
                      </div>
                      <p className="text-xs text-gray-500 mt-1">{item.category}</p>
                      {item.description && (
                        <p className="text-sm text-gray-600 mt-1 line-clamp-2">{item.description}</p>
                      )}
                      <div className="flex items-center gap-2 mt-2">
                        <span className={`text-xs px-2 py-1 rounded-full ${item.is_available ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                          {item.is_available ? 'Available' : 'Unavailable'}
                        </span>
                      </div>
                      <div className="flex gap-2 mt-3">
                        <button
                          onClick={() => startEditMenuItem(item)}
                          className="flex items-center gap-1 text-purple-600 hover:text-purple-800 text-sm font-medium"
                        >
                          <Edit2 className="w-3 h-3" />
                          Edit
                        </button>
                        <button
                          onClick={() => deleteMenuItem(item.id)}
                          className="flex items-center gap-1 text-red-600 hover:text-red-800 text-sm font-medium"
                        >
                          <Trash2 className="w-3 h-3" />
                          Delete
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="space-y-6">
            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <h2 className="text-xl font-bold text-gray-900 mb-2">Contact Details</h2>
              <p className="text-gray-600 mb-6">Update the contact information displayed on the menu page</p>
              
              <form onSubmit={updateSettings} className="space-y-4 max-w-lg">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Primary Phone Number</label>
                  <input
                    type="text"
                    value={settings.phone_1}
                    onChange={(e) => setSettings({ ...settings, phone_1: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    placeholder="+91 98765 43210"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Secondary Phone Number</label>
                  <input
                    type="text"
                    value={settings.phone_2}
                    onChange={(e) => setSettings({ ...settings, phone_2: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    placeholder="+91 98765 43211"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                  <input
                    type="email"
                    value={settings.email}
                    onChange={(e) => setSettings({ ...settings, email: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    placeholder="info@yaranacafe.com"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-gradient-to-r from-purple-500 to-purple-600 text-white py-3 rounded-lg font-medium hover:from-purple-600 hover:to-purple-700 transition-all shadow-md"
                >
                  Save Settings
                </button>
              </form>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <h2 className="text-xl font-bold text-gray-900 mb-2">Order Settings</h2>
              <p className="text-gray-600 mb-6">Configure minimum order amount for delivery orders</p>
              
              <form onSubmit={updateSettings} className="space-y-4 max-w-lg">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Minimum Order Amount (₹)
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={settings.minimum_order_amount}
                    onChange={(e) => setSettings({ ...settings, minimum_order_amount: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    placeholder="0"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Applies only to delivery orders. Set to 0 to disable. Table orders have no minimum.
                  </p>
                </div>

                <button
                  type="submit"
                  className="w-full bg-gradient-to-r from-purple-500 to-purple-600 text-white py-3 rounded-lg font-medium hover:from-purple-600 hover:to-purple-700 transition-all shadow-md"
                >
                  Save Settings
                </button>
              </form>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <h2 className="text-xl font-bold text-gray-900 mb-2">Payment QR Code</h2>
              <p className="text-gray-600 mb-6">Upload your payment QR code URL for customer payments</p>
              
              <form onSubmit={updateSettings} className="space-y-4 max-w-lg">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Payment QR Image URL</label>
                  <input
                    type="url"
                    value={settings.payment_qr_url}
                    onChange={(e) => setSettings({ ...settings, payment_qr_url: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    placeholder="https://example.com/payment-qr.png"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Enter the direct URL to your UPI payment QR code image
                  </p>
                </div>

                {settings.payment_qr_url && (
                  <div className="border-2 border-gray-200 rounded-lg p-4 text-center">
                    <p className="text-sm text-gray-600 mb-2">Preview:</p>
                    <img
                      src={settings.payment_qr_url}
                      alt="Payment QR Preview"
                      className="w-48 h-48 mx-auto border border-gray-200 rounded-lg"
                      onError={(e) => {
                        (e.target as HTMLImageElement).style.display = 'none';
                      }}
                    />
                  </div>
                )}

                <button
                  type="submit"
                  className="w-full bg-gradient-to-r from-purple-500 to-purple-600 text-white py-3 rounded-lg font-medium hover:from-purple-600 hover:to-purple-700 transition-all shadow-md"
                >
                  Save Settings
                </button>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
