import { useEffect } from 'react';
import { useAuth } from '@getmocha/users-service/react';
import { useNavigate } from 'react-router';
import { ChefHat, Bike, Shield, ArrowRight } from 'lucide-react';

export default function Landing() {
  const { user, isPending, redirectToLogin } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isPending && user) {
      const role = (user as any).role;
      if (role === 'admin') {
        navigate('/admin');
      } else if (role === 'rider') {
        navigate('/rider');
      } else {
        navigate('/menu');
      }
    }
  }, [user, isPending, navigate]);

  const handleLogin = () => {
    redirectToLogin();
  };

  if (isPending) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-orange-100 via-orange-50 to-white">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-orange-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600 text-lg">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-100 via-orange-50 to-white">
      <div className="max-w-7xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="flex justify-center mb-6">
            <img 
              src="https://019c18bd-977d-7a24-957e-b7597cd8059d.mochausercontent.com/Gemini_Generated_Image_p3i1ggp3i1ggp3i1-(1)-(1).png" 
              alt="Yarana Cafe Kudwar" 
              className="h-32 w-32 object-contain"
            />
          </div>
          <h1 className="text-6xl font-bold bg-gradient-to-r from-orange-600 via-orange-500 to-orange-600 bg-clip-text text-transparent mb-4">
            Yarana Cafe Kudwar
          </h1>
          <p className="text-2xl text-gray-700 font-medium">Fresh Food Delivered to Your Door</p>
          <p className="text-lg text-gray-600 mt-2">Sign in with Google to get started</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto mb-12">
          <div className="bg-white rounded-2xl p-8 shadow-lg border-2 border-orange-200 hover:border-orange-400 transition-all transform hover:-translate-y-1">
            <div className="w-16 h-16 bg-gradient-to-br from-orange-400 to-orange-500 rounded-full flex items-center justify-center mb-6">
              <ChefHat className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-3">For Customers</h3>
            <p className="text-gray-600 mb-6">
              Browse our delicious menu, place orders, and track deliveries in real-time
            </p>
            <ul className="space-y-2 text-sm text-gray-600 mb-6">
              <li className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 bg-orange-500 rounded-full"></div>
                Order from authentic Indian dishes
              </li>
              <li className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 bg-orange-500 rounded-full"></div>
                Track order status live
              </li>
              <li className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 bg-orange-500 rounded-full"></div>
                View order history
              </li>
            </ul>
            <button
              onClick={handleLogin}
              className="w-full bg-gradient-to-r from-orange-500 to-orange-600 text-white py-3 rounded-lg font-medium hover:from-orange-600 hover:to-orange-700 transition-all shadow-md"
            >
              Sign in to Order
            </button>
            <button
              onClick={() => navigate('/menu')}
              className="w-full mt-3 bg-white text-orange-600 py-3 rounded-lg font-medium border-2 border-orange-200 hover:border-orange-400 hover:bg-orange-50 transition-all"
            >
              Continue as Guest
            </button>
          </div>

          <div className="bg-white rounded-2xl p-8 shadow-lg border-2 border-blue-200 hover:border-blue-400 transition-all transform hover:-translate-y-1">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-400 to-blue-500 rounded-full flex items-center justify-center mb-6">
              <Bike className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-3">For Riders</h3>
            <p className="text-gray-600 mb-6">
              Accept delivery requests and manage your active deliveries efficiently
            </p>
            <ul className="space-y-2 text-sm text-gray-600 mb-6">
              <li className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 bg-blue-500 rounded-full"></div>
                View available orders
              </li>
              <li className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 bg-blue-500 rounded-full"></div>
                Accept deliveries
              </li>
              <li className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 bg-blue-500 rounded-full"></div>
                Update delivery status
              </li>
            </ul>
            <button
              onClick={() => navigate('/rider')}
              className="w-full bg-gradient-to-r from-blue-500 to-blue-600 text-white py-3 rounded-lg font-medium hover:from-blue-600 hover:to-blue-700 transition-all shadow-md"
            >
              Rider Login
            </button>
          </div>

          <div className="bg-white rounded-2xl p-8 shadow-lg border-2 border-purple-200 hover:border-purple-400 transition-all transform hover:-translate-y-1">
            <div className="w-16 h-16 bg-gradient-to-br from-purple-400 to-purple-500 rounded-full flex items-center justify-center mb-6">
              <Shield className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-3">For Admins</h3>
            <p className="text-gray-600 mb-6">
              Manage orders, assign riders, and oversee all operations from one dashboard
            </p>
            <ul className="space-y-2 text-sm text-gray-600 mb-6">
              <li className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 bg-purple-500 rounded-full"></div>
                Manage all orders
              </li>
              <li className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 bg-purple-500 rounded-full"></div>
                Assign riders to orders
              </li>
              <li className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 bg-purple-500 rounded-full"></div>
                Manage user roles
              </li>
            </ul>
            <button
              onClick={() => navigate('/admin')}
              className="w-full bg-gradient-to-r from-purple-500 to-purple-600 text-white py-3 rounded-lg font-medium hover:from-purple-600 hover:to-purple-700 transition-all shadow-md"
            >
              Admin Login
            </button>
          </div>
        </div>

        <div className="text-center">
          <button
            onClick={() => navigate('/menu')}
            className="group inline-flex items-center gap-3 px-12 py-5 bg-gradient-to-r from-orange-500 to-orange-600 text-white text-xl font-bold rounded-full hover:from-orange-600 hover:to-orange-700 transition-all shadow-xl hover:shadow-2xl transform hover:-translate-y-1"
          >
            View Menu
            <ArrowRight className="w-6 h-6 group-hover:translate-x-1 transition-transform" />
          </button>
          <p className="text-sm text-gray-600 mt-6">
            Click the buttons above to access Admin, Rider, or Customer portals
          </p>
        </div>
      </div>
    </div>
  );
}
