import { useState } from 'react';
import { useNavigate } from 'react-router';
import { QrCode, Download, ArrowLeft } from 'lucide-react';

export default function QRGenerator() {
  const navigate = useNavigate();
  const [password, setPassword] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [error, setError] = useState('');
  const [numTables, setNumTables] = useState(10);

  const baseUrl = window.location.origin;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === 'Yaranacafe8948') {
      setIsAuthenticated(true);
      setError('');
    } else {
      setError('Incorrect password');
    }
  };

  const generateQRCodeUrl = (tableNumber: number) => {
    const tableUrl = `${baseUrl}/table?table=${tableNumber}`;
    return `https://api.qrserver.com/v1/create-qr-code/?size=400x400&data=${encodeURIComponent(tableUrl)}`;
  };

  const downloadQRCode = async (tableNumber: number) => {
    const qrUrl = generateQRCodeUrl(tableNumber);
    try {
      const response = await fetch(qrUrl);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `table-${tableNumber}-qr.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error downloading QR code:', error);
      alert('Failed to download QR code');
    }
  };

  const downloadAllQRCodes = async () => {
    for (let i = 1; i <= numTables; i++) {
      await new Promise(resolve => setTimeout(resolve, 500)); // Delay between downloads
      await downloadQRCode(i);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-50 via-white to-purple-50">
        <div className="bg-white p-8 rounded-2xl shadow-xl border border-gray-200 w-full max-w-md">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <QrCode className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900">QR Code Generator</h2>
            <p className="text-gray-600 mt-2">Admin Access Required</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="Enter admin password"
                autoFocus
              />
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
                {error}
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-gradient-to-r from-purple-500 to-purple-600 text-white py-3 rounded-lg font-medium hover:from-purple-600 hover:to-purple-700 transition-all shadow-md"
            >
              Login
            </button>

            <button
              type="button"
              onClick={() => navigate('/admin')}
              className="w-full bg-gray-100 text-gray-700 py-3 rounded-lg font-medium hover:bg-gray-200 transition-colors"
            >
              Back to Dashboard
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-purple-50">
      <header className="bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img 
                src="https://019c18bd-977d-7a24-957e-b7597cd8059d.mochausercontent.com/Gemini_Generated_Image_p3i1ggp3i1ggp3i1-(1)-(1).png" 
                alt="Yarana Cafe Kudwar" 
                className="h-12 w-12 object-contain"
              />
              <div>
                <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-purple-500 bg-clip-text text-transparent">
                  Table QR Codes
                </h1>
                <p className="text-sm text-gray-600 mt-1">Generate QR codes for table ordering</p>
              </div>
            </div>
            <button
              onClick={() => navigate('/admin')}
              className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200 transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Dashboard
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-8">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Generate QR Codes</h2>
          <div className="flex items-center gap-4 mb-4">
            <div className="flex-1">
              <label className="block text-sm font-medium text-gray-700 mb-2">Number of Tables</label>
              <input
                type="number"
                min="1"
                max="100"
                value={numTables}
                onChange={(e) => setNumTables(parseInt(e.target.value) || 1)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              />
            </div>
            <button
              onClick={downloadAllQRCodes}
              className="mt-7 flex items-center gap-2 px-6 py-2 bg-gradient-to-r from-purple-500 to-purple-600 text-white rounded-lg font-medium hover:from-purple-600 hover:to-purple-700 transition-all shadow-md"
            >
              <Download className="w-4 h-4" />
              Download All
            </button>
          </div>
          <p className="text-sm text-gray-600">
            Each QR code will open the menu directly for the specified table. Customers can scan and order without registration.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {Array.from({ length: numTables }, (_, i) => i + 1).map((tableNumber) => (
            <div key={tableNumber} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
              <div className="text-center mb-4">
                <h3 className="text-2xl font-bold text-purple-600 mb-1">Table {tableNumber}</h3>
                <p className="text-sm text-gray-600">{baseUrl}/table?table={tableNumber}</p>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-4 mb-4">
                <img
                  src={generateQRCodeUrl(tableNumber)}
                  alt={`Table ${tableNumber} QR Code`}
                  className="w-full h-auto"
                />
              </div>

              <button
                onClick={() => downloadQRCode(tableNumber)}
                className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-gradient-to-r from-orange-500 to-orange-600 text-white rounded-lg font-medium hover:from-orange-600 hover:to-orange-700 transition-all shadow-md"
              >
                <Download className="w-4 h-4" />
                Download QR
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
