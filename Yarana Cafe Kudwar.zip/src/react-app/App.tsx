import { BrowserRouter as Router, Routes, Route } from "react-router";
import { AuthProvider } from "@getmocha/users-service/react";
import Landing from "@/react-app/pages/Landing";
import MenuPage from "@/react-app/pages/Menu";
import AuthCallbackPage from "@/react-app/pages/AuthCallback";
import AdminDashboard from "@/react-app/pages/AdminDashboard";
import RiderDashboard from "@/react-app/pages/RiderDashboard";
import OrderHistory from "@/react-app/pages/OrderHistory";
import TableOrder from "@/react-app/pages/TableOrder";
import QRGenerator from "@/react-app/pages/QRGenerator";

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/menu" element={<MenuPage />} />
          <Route path="/orders" element={<OrderHistory />} />
          <Route path="/auth/callback" element={<AuthCallbackPage />} />
          <Route path="/admin" element={<AdminDashboard />} />
          <Route path="/admin/qr" element={<QRGenerator />} />
          <Route path="/rider" element={<RiderDashboard />} />
          <Route path="/table" element={<TableOrder />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}
