import { useEffect, useState } from 'react';
import { Check, X } from 'lucide-react';

interface OrderSuccessModalProps {
  isOpen: boolean;
  onClose: () => void;
  orderNumber: string;
}

export default function OrderSuccessModal({ isOpen, onClose, orderNumber }: OrderSuccessModalProps) {
  const [showCheck, setShowCheck] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => setShowCheck(true), 200);
    } else {
      setShowCheck(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-8 text-center relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 hover:bg-gray-100 rounded-full transition-colors"
        >
          <X className="w-5 h-5 text-gray-600" />
        </button>

        <div className="mb-6">
          <div
            className={`w-24 h-24 mx-auto rounded-full bg-gradient-to-br from-green-400 to-green-500 flex items-center justify-center shadow-lg transform transition-all duration-700 ${
              showCheck ? 'scale-100 rotate-0 opacity-100' : 'scale-0 rotate-180 opacity-0'
            }`}
          >
            <div className="absolute inset-0 rounded-full bg-green-400 animate-ping opacity-30"></div>
            <Check className="w-14 h-14 text-white relative z-10" strokeWidth={3} />
          </div>
        </div>

        <h2 className="text-3xl font-bold text-gray-900 mb-3">Order Placed!</h2>
        <p className="text-gray-600 mb-2">Your order has been successfully placed.</p>
        <p className="text-sm text-gray-500 mb-6">
          Order Number: <span className="font-bold text-orange-600">{orderNumber}</span>
        </p>

        <div className="bg-orange-50 border border-orange-200 rounded-lg p-4 mb-6">
          <p className="text-sm text-gray-700">
            Track your order status in the <span className="font-semibold">Order History</span> section
          </p>
        </div>

        <button
          onClick={onClose}
          className="w-full bg-gradient-to-r from-orange-500 to-orange-600 text-white py-3 rounded-lg font-bold hover:from-orange-600 hover:to-orange-700 transition-all shadow-md"
        >
          Continue Shopping
        </button>
      </div>
    </div>
  );
}
