import { useState, useRef, useEffect } from 'react';
import { User, LogOut, UserCircle, LayoutDashboard } from 'lucide-react';
import { useAuth } from '@getmocha/users-service/react';
import { useNavigate } from 'react-router';

export default function UserMenu() {
  const { user, logout, redirectToLogin } = useAuth();
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleLogout = async () => {
    await logout();
    setIsOpen(false);
  };

  if (!user) {
    return (
      <button
        onClick={redirectToLogin}
        className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-orange-500 to-orange-600 text-white rounded-lg font-medium hover:from-orange-600 hover:to-orange-700 transition-all shadow-md hover:shadow-lg"
      >
        <User className="w-5 h-5" />
        Sign In
      </button>
    );
  }

  const getRoleBadge = () => {
    const role = (user as any).role || 'customer';
    const colors = {
      admin: 'bg-purple-100 text-purple-700',
      rider: 'bg-blue-100 text-blue-700',
      customer: 'bg-gray-100 text-gray-700',
    };
    return (
      <span className={`text-xs px-2 py-0.5 rounded-full ${colors[role as keyof typeof colors]}`}>
        {role.charAt(0).toUpperCase() + role.slice(1)}
      </span>
    );
  };

  return (
    <div className="relative" ref={menuRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 p-2 hover:bg-gray-100 rounded-full transition-colors"
      >
        {user.google_user_data.picture ? (
          <img
            src={user.google_user_data.picture}
            alt={user.email}
            className="w-8 h-8 rounded-full"
          />
        ) : (
          <UserCircle className="w-8 h-8 text-gray-600" />
        )}
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-64 bg-white rounded-lg shadow-xl border border-gray-200 overflow-hidden z-50">
          <div className="p-4 bg-gradient-to-r from-orange-50 to-orange-100 border-b border-gray-200">
            <div className="flex items-center gap-3">
              {user.google_user_data.picture ? (
                <img
                  src={user.google_user_data.picture}
                  alt={user.email}
                  className="w-12 h-12 rounded-full"
                />
              ) : (
                <div className="w-12 h-12 bg-orange-200 rounded-full flex items-center justify-center">
                  <User className="w-6 h-6 text-orange-700" />
                </div>
              )}
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-gray-900 truncate">
                  {user.google_user_data.name || user.email}
                </p>
                <p className="text-sm text-gray-600 truncate">{user.email}</p>
                {getRoleBadge()}
              </div>
            </div>
          </div>

          <div className="p-2">
            {((user as any).role === 'admin' || (user as any).role === 'rider') && (
              <button
                onClick={() => {
                  navigate((user as any).role === 'admin' ? '/admin' : '/rider');
                  setIsOpen(false);
                }}
                className="w-full flex items-center gap-3 px-3 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors mb-1"
              >
                <LayoutDashboard className="w-5 h-5" />
                <span className="font-medium">Dashboard</span>
              </button>
            )}
            <button
              onClick={handleLogout}
              className="w-full flex items-center gap-3 px-3 py-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
            >
              <LogOut className="w-5 h-5" />
              <span className="font-medium">Sign Out</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
