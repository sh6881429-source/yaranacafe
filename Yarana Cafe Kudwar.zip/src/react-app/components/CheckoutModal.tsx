import { useState, useEffect } from 'react';
import { X, MapPin, Phone, User, CreditCard, CheckCircle } from 'lucide-react';
import { useAuth } from '@getmocha/users-service/react';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: Array<{ id: string; name: string; price: number; quantity: number }>;
  onSuccess: (orderNumber: string) => void;
  orderType?: 'delivery' | 'table';
  tableNumber?: string;
}

export default function CheckoutModal({ 
  isOpen, 
  onClose, 
  cartItems, 
  onSuccess,
  orderType = 'delivery',
  tableNumber 
}: CheckoutModalProps) {
  const { user } = useAuth();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);
  const [paymentOption, setPaymentOption] = useState<'advance' | 'full'>('advance');
  const [utrNumber, setUtrNumber] = useState('');
  const [showPaymentQR, setShowPaymentQR] = useState(false);
  const [paymentQRUrl, setPaymentQRUrl] = useState('');
  const [paymentConfirmed, setPaymentConfirmed] = useState(false);
  const [minOrderAmount, setMinOrderAmount] = useState(0);
  const [minOrderError, setMinOrderError] = useState('');

  const totalAmount = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const paidAmount = paymentOption === 'advance' ? 50 : totalAmount;

  // Fetch settings
  useEffect(() => {
    if (isOpen) {
      fetchSettings();
    }
  }, [isOpen]);

  // Pre-fill form with user data when modal opens (only for logged-in users)
  useEffect(() => {
    if (user && isOpen) {
      setName((user as any)?.name || '');
      setPhone((user as any)?.phone || '');
      setAddress((user as any)?.address || '');
    }
  }, [user, isOpen]);

  const fetchSettings = async () => {
    try {
      const response = await fetch('/api/settings');
      const data = await response.json();
      setPaymentQRUrl(data.payment_qr_url || '');
      setMinOrderAmount(parseInt(data.minimum_order_amount) || 0);
    } catch (error) {
      console.error('Error fetching settings:', error);
    }
  };

  const handleProceedToPayment = () => {
    setMinOrderError('');
    
    // Validate minimum order for delivery only
    if (orderType === 'delivery' && minOrderAmount > 0 && totalAmount < minOrderAmount) {
      setMinOrderError(`Minimum order amount is ₹${minOrderAmount} for delivery orders`);
      return;
    }

    if (!name || !phone) {
      alert('Please enter your name and phone number');
      return;
    }

    if (orderType === 'delivery' && !address) {
      alert('Please enter your delivery address');
      return;
    }

    setShowPaymentQR(true);
  };

  const handleConfirmPayment = () => {
    if (!utrNumber) {
      alert('Please enter the 12-digit UTR number');
      return;
    }

    if (utrNumber.length !== 12 || !/^\d+$/.test(utrNumber)) {
      alert('UTR number must be exactly 12 digits');
      return;
    }

    setPaymentConfirmed(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Use guest order endpoint if not logged in, otherwise use authenticated endpoint
      const endpoint = user ? '/api/orders' : '/api/orders/guest';
      
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          items: cartItems,
          name,
          address: orderType === 'table' ? `Table ${tableNumber}` : address,
          phone,
          notes,
          order_type: orderType,
          table_number: orderType === 'table' ? tableNumber : null,
          payment_option: orderType === 'delivery' ? paymentOption : null,
          paid_amount: orderType === 'delivery' ? paidAmount : null,
          utr_number: orderType === 'delivery' ? utrNumber : null,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        // Update user profile if logged in and data changed
        if (user && (phone !== (user as any)?.phone || address !== (user as any)?.address || name !== (user as any)?.name)) {
          await fetch('/api/users/me', {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, phone, address }),
          });
        }

        onSuccess(data.orderNumber);
      } else {
        alert(data.error || 'Failed to place order');
      }
    } catch (error) {
      console.error('Error placing order:', error);
      alert('Failed to place order');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  // Table orders skip payment
  if (orderType === 'table') {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
          <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Complete Your Order</h2>
              <p className="text-sm text-gray-600 mt-1">Table {tableNumber}</p>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <X className="w-6 h-6 text-gray-600" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="p-6">
            <div className="space-y-4 mb-6">
              <div>
                <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                  <User className="w-4 h-4" />
                  Full Name
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  placeholder="Enter your name"
                />
              </div>

              <div>
                <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                  <Phone className="w-4 h-4" />
                  Phone Number
                </label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  placeholder="Enter your phone number"
                />
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">
                  Special Instructions (Optional)
                </label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={2}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent resize-none"
                  placeholder="Any special requests?"
                />
              </div>
            </div>

            <div className="border-t border-gray-200 pt-6 mb-6">
              <h3 className="font-semibold text-gray-900 mb-3">Order Summary</h3>
              <div className="space-y-2 mb-4">
                {cartItems.map((item) => (
                  <div key={item.id} className="flex justify-between text-sm">
                    <span className="text-gray-600">
                      {item.name} x{item.quantity}
                    </span>
                    <span className="font-medium text-gray-900">₹{item.price * item.quantity}</span>
                  </div>
                ))}
              </div>
              <div className="flex justify-between text-lg font-bold border-t border-gray-200 pt-3">
                <span>Total</span>
                <span className="text-orange-600">₹{totalAmount}</span>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-orange-500 to-orange-600 text-white py-4 rounded-lg font-bold text-lg hover:from-orange-600 hover:to-orange-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
            >
              {loading ? 'Placing Order...' : 'Place Order'}
            </button>
          </form>
        </div>
      </div>
    );
  }

  // Delivery orders with payment
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex items-center justify-center z-50 p-2 sm:p-4">
      <div className="bg-white rounded-xl sm:rounded-2xl shadow-2xl max-w-2xl w-full max-h-[95vh] sm:max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-gray-200 px-4 sm:px-6 py-3 sm:py-4 flex items-center justify-between z-10">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-gray-900">
              {showPaymentQR ? 'Payment' : 'Delivery Details'}
            </h2>
            {!user && !showPaymentQR && (
              <p className="text-sm text-gray-600 mt-1">Ordering as guest - no account required</p>
            )}
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="w-6 h-6 text-gray-600" />
          </button>
        </div>

        {!showPaymentQR ? (
          <div className="p-6">
            <div className="space-y-4 mb-6">
              <div>
                <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                  <User className="w-4 h-4" />
                  Full Name
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  placeholder="Enter your name"
                />
              </div>

              <div>
                <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                  <Phone className="w-4 h-4" />
                  Phone Number
                </label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  placeholder="Enter your phone number"
                />
              </div>

              <div>
                <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                  <MapPin className="w-4 h-4" />
                  Delivery Address
                </label>
                <textarea
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  required
                  rows={3}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent resize-none"
                  placeholder="Enter complete delivery address"
                />
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">
                  Special Instructions (Optional)
                </label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={2}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent resize-none"
                  placeholder="Any special requests?"
                />
              </div>
            </div>

            <div className="border-t border-gray-200 pt-6 mb-6">
              <h3 className="font-semibold text-gray-900 mb-3">Order Summary</h3>
              <div className="space-y-2 mb-4">
                {cartItems.map((item) => (
                  <div key={item.id} className="flex justify-between text-sm">
                    <span className="text-gray-600">
                      {item.name} x{item.quantity}
                    </span>
                    <span className="font-medium text-gray-900">₹{item.price * item.quantity}</span>
                  </div>
                ))}
              </div>
              <div className="flex justify-between text-lg font-bold border-t border-gray-200 pt-3">
                <span>Total</span>
                <span className="text-orange-600">₹{totalAmount}</span>
              </div>
              {minOrderAmount > 0 && (
                <p className="text-xs text-gray-500 mt-2">Minimum order: ₹{minOrderAmount}</p>
              )}
            </div>

            {minOrderError && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm mb-4">
                {minOrderError}
              </div>
            )}

            <button
              onClick={handleProceedToPayment}
              className="w-full bg-gradient-to-r from-orange-500 to-orange-600 text-white py-4 rounded-lg font-bold text-lg hover:from-orange-600 hover:to-orange-700 transition-all shadow-lg"
            >
              Proceed to Payment
            </button>
          </div>
        ) : !paymentConfirmed ? (
          <div className="p-6">
            <div className="bg-orange-50 border-2 border-orange-200 rounded-xl p-6 mb-6">
              <h3 className="font-bold text-gray-900 mb-4 text-lg">Select Payment Option</h3>
              <div className="space-y-3">
                <label className="flex items-center gap-3 p-4 border-2 rounded-lg cursor-pointer transition-all hover:border-orange-300 bg-white">
                  <input
                    type="radio"
                    name="payment"
                    value="advance"
                    checked={paymentOption === 'advance'}
                    onChange={() => setPaymentOption('advance')}
                    className="w-5 h-5 text-orange-500"
                  />
                  <div className="flex-1">
                    <p className="font-bold text-gray-900">Pay ₹50 Advance</p>
                    <p className="text-sm text-gray-600">Pay remaining ₹{totalAmount - 50} on delivery</p>
                  </div>
                  <span className="text-2xl font-bold text-orange-600">₹50</span>
                </label>

                <label className="flex items-center gap-3 p-4 border-2 rounded-lg cursor-pointer transition-all hover:border-orange-300 bg-white">
                  <input
                    type="radio"
                    name="payment"
                    value="full"
                    checked={paymentOption === 'full'}
                    onChange={() => setPaymentOption('full')}
                    className="w-5 h-5 text-orange-500"
                  />
                  <div className="flex-1">
                    <p className="font-bold text-gray-900">Pay Full Amount</p>
                    <p className="text-sm text-gray-600">Pay complete order amount now</p>
                  </div>
                  <span className="text-2xl font-bold text-orange-600">₹{totalAmount}</span>
                </label>
              </div>
            </div>

            {paymentQRUrl && (
              <div className="bg-white border-2 border-gray-200 rounded-xl p-4 sm:p-6 mb-6 text-center">
                <h3 className="font-bold text-gray-900 mb-3 sm:mb-4 text-base sm:text-lg">Scan QR to Pay</h3>
                <img
                  src={paymentQRUrl}
                  alt="Payment QR Code"
                  className="w-48 h-48 sm:w-64 sm:h-64 mx-auto mb-3 sm:mb-4 border-2 border-gray-200 rounded-lg"
                  onError={(e) => {
                    (e.target as HTMLImageElement).style.display = 'none';
                  }}
                />
                <p className="text-xs sm:text-sm text-gray-600 mb-2">Scan with any UPI app</p>
                <p className="text-xl sm:text-2xl font-bold text-orange-600">₹{paidAmount}</p>
              </div>
            )}

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
              <p className="text-sm text-blue-800 font-medium mb-2">After payment:</p>
              <p className="text-sm text-blue-700">Enter the 12-digit UTR number from your payment confirmation</p>
            </div>

            <div className="mb-6">
              <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                <CreditCard className="w-4 h-4" />
                UTR Number (12 digits)
              </label>
              <input
                type="text"
                value={utrNumber}
                onChange={(e) => {
                  const value = e.target.value.replace(/\D/g, '').slice(0, 12);
                  setUtrNumber(value);
                }}
                maxLength={12}
                className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent font-mono text-lg"
                placeholder="Enter 12-digit UTR"
              />
              <p className="text-xs text-gray-500 mt-1">
                {utrNumber.length}/12 digits
              </p>
            </div>

            <button
              onClick={handleConfirmPayment}
              disabled={utrNumber.length !== 12}
              className="w-full bg-gradient-to-r from-green-500 to-green-600 text-white py-4 rounded-lg font-bold text-lg hover:from-green-600 hover:to-green-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
            >
              <CheckCircle className="w-5 h-5 inline mr-2" />
              Confirm Payment
            </button>

            <button
              onClick={() => setShowPaymentQR(false)}
              className="w-full mt-3 bg-gray-100 text-gray-700 py-3 rounded-lg font-medium hover:bg-gray-200 transition-all"
            >
              Back
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6">
            <div className="bg-green-50 border-2 border-green-200 rounded-xl p-6 mb-6 text-center">
              <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Payment Confirmed!</h3>
              <p className="text-gray-600 mb-4">UTR: {utrNumber}</p>
              <p className="text-sm text-gray-600">
                Your payment will be verified by admin. Order will proceed after verification.
              </p>
            </div>

            <div className="bg-white border border-gray-200 rounded-lg p-4 mb-6">
              <div className="flex justify-between mb-2">
                <span className="text-gray-600">Paid Amount:</span>
                <span className="font-bold text-green-600">₹{paidAmount}</span>
              </div>
              {paymentOption === 'advance' && (
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Pay on Delivery:</span>
                  <span className="font-medium text-orange-600">₹{totalAmount - 50}</span>
                </div>
              )}
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-orange-500 to-orange-600 text-white py-4 rounded-lg font-bold text-lg hover:from-orange-600 hover:to-orange-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
            >
              {loading ? 'Placing Order...' : 'Place Order'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
