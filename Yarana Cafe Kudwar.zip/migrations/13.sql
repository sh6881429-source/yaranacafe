
ALTER TABLE orders ADD COLUMN order_type TEXT DEFAULT 'delivery';
ALTER TABLE orders ADD COLUMN table_number TEXT;
ALTER TABLE orders ADD COLUMN payment_option TEXT;
ALTER TABLE orders ADD COLUMN paid_amount INTEGER;
ALTER TABLE orders ADD COLUMN utr_number TEXT;
ALTER TABLE orders ADD COLUMN is_payment_verified INTEGER DEFAULT 0;

INSERT INTO settings (key, value) VALUES ('minimum_order_amount', '0');
INSERT INTO settings (key, value) VALUES ('payment_qr_url', '');
