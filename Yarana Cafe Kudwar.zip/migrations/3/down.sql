
DROP TABLE settings;
ALTER TABLE users DROP COLUMN password;
