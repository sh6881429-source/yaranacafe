
CREATE TABLE menu_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT,
  price INTEGER NOT NULL,
  category TEXT NOT NULL,
  image TEXT,
  is_veg BOOLEAN DEFAULT 1,
  is_available BOOLEAN DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO menu_items (name, description, price, category, image, is_veg, is_available) VALUES
('Paneer Tikka Masala', 'Cottage cheese cubes in rich tomato and cream gravy', 280, 'Main Course', 'https://images.unsplash.com/photo-1631452180519-c014fe946bc7?w=400', 1, 1),
('Butter Chicken', 'Tender chicken in creamy tomato butter sauce', 320, 'Main Course', 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?w=400', 0, 1),
('Dal Makhani', 'Black lentils slow-cooked with butter and cream', 220, 'Main Course', 'https://images.unsplash.com/photo-1546833998-877b37c2e5c6?w=400', 1, 1),
('Chicken Biryani', 'Fragrant basmati rice with tender chicken pieces', 350, 'Rice', 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=400', 0, 1),
('Veg Biryani', 'Aromatic rice with mixed vegetables and spices', 280, 'Rice', 'https://images.unsplash.com/photo-1642821373181-696a54913e93?w=400', 1, 1),
('Garlic Naan', 'Freshly baked bread with garlic and butter', 60, 'Bread', 'https://images.unsplash.com/photo-1619888355804-42a785e93d40?w=400', 1, 1),
('Tandoori Roti', 'Whole wheat bread from clay oven', 40, 'Bread', 'https://images.unsplash.com/photo-1628840042765-356cda07504e?w=400', 1, 1),
('Samosa', 'Crispy pastry filled with spiced potatoes and peas', 50, 'Starters', 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=400', 1, 1),
('Chicken 65', 'Spicy deep-fried chicken appetizer', 240, 'Starters', 'https://images.unsplash.com/photo-1610057099443-fde8c4d50f91?w=400', 0, 1),
('Gulab Jamun', 'Soft milk dumplings in sugar syrup', 80, 'Desserts', 'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?w=400', 1, 1),
('Mango Lassi', 'Sweet yogurt drink with mango pulp', 90, 'Beverages', 'https://images.unsplash.com/photo-1623065422902-30a2d299bbe4?w=400', 1, 1),
('Masala Chai', 'Traditional Indian spiced tea', 40, 'Beverages', 'https://images.unsplash.com/photo-1597481499750-3e6b22637e12?w=400', 1, 1);
