
DROP TABLE menu_items;
