
DROP INDEX idx_order_items_order_id;
DROP INDEX idx_orders_status;
DROP INDEX idx_orders_rider_id;
DROP INDEX idx_orders_customer_id;
DROP TABLE order_items;
DROP TABLE orders;
