
ALTER TABLE users ADD COLUMN password TEXT;

CREATE TABLE settings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  key TEXT NOT NULL UNIQUE,
  value TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO settings (key, value) VALUES ('phone_1', '+91 98765 43210');
INSERT INTO settings (key, value) VALUES ('phone_2', '+91 98765 43211');
INSERT INTO settings (key, value) VALUES ('email', 'info@yaranacafe.com');
