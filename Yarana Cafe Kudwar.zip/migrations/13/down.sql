
DELETE FROM settings WHERE key = 'payment_qr_url';
DELETE FROM settings WHERE key = 'minimum_order_amount';

ALTER TABLE orders DROP COLUMN is_payment_verified;
ALTER TABLE orders DROP COLUMN utr_number;
ALTER TABLE orders DROP COLUMN paid_amount;
ALTER TABLE orders DROP COLUMN payment_option;
ALTER TABLE orders DROP COLUMN table_number;
ALTER TABLE orders DROP COLUMN order_type;
